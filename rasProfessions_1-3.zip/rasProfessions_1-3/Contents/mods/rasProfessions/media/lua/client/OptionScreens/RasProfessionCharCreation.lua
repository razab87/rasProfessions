-- we modify the random dress-up of a character in the character customisation screen (i.e. the function CharacterCreationHeader.dressWithDefinitions from vanilla lua/client/OptionScreens);
-- in some cases, a body location should only get clothing from a specific choice of clothing items for that location (for example: no fedora hats for lumberjacks but baseball cap is ok; player can still manually choose 
-- fedora if desired); we also exclude some other weird clothing combinations and make it so that professions don't get inappropriate hair styles assigned (player can still maunally choose those combinations or hair styles)
--
--
-- by razab




local vanilla_dressWithDefinitions = CharacterCreationHeader.dressWithDefinitions
function CharacterCreationHeader.dressWithDefinitions(self, definition, resetWornItems, ...)

     vanilla_dressWithDefinitions(self, definition, resetWornItems, ...) -- execute vanilla code

     local desc = MainScreen.instance.desc
     local profession = desc:getProfession()

     if profession and not resetWornItems then -- in case resetWornItems = false, characters are dressed with profession specific clothing (according to vanilla code...)            
            local rasTable = RasProfessionsClothingDefinitions
            if rasTable[profession] then
                 if rasTable[profession]["Special"] then -- only if we defined "Special" in our table RasProfessionsClothingDefinitions 
                                if rasTable[profession]["Special"]["Female"] then
                                      local currentTable = rasTable[profession]["Special"]["Female"] 
                                      for bodyLocation, value in pairs(currentTable) do
                                             if not(bodyLocation == "Shirt" and desc:getWornItem("Dress")) then -- shirt and dress are mutually exclusive; so don't apply in this case
                                                 local items = value.items
                                                 local chance = value.chance -- note: value.chance should always be defined in our table
                                                 desc:setWornItem(bodyLocation, nil)
                                                 if chance and ZombRand(100) < chance then
                                                      local itemType = items[ZombRand(0, #items) + 1]
                                                      local clothingItem = InventoryItemFactory.CreateItem(itemType)
                                                      desc:setWornItem(bodyLocation, clothingItem)
                                                 end
                                             end
                                      end
                                end
                                if not desc:isFemale() then
                                      if rasTable[profession]["Special"]["Male"] then -- in case men get special treatment (by default, it is the same as for women)
                                           local currentTable = rasTable[profession]["Special"]["Male"] 
                                           for bodyLocation, value in pairs(currentTable) do
                                                  local items = value.items
                                                  local chance = value.chance -- note: value.chance should always be defined in our table
                                                  desc:setWornItem(bodyLocation, nil)
                                                  if chance and ZombRand(100) < chance then
                                                       local itemType = items[ZombRand(0, #items) + 1]
                                                       local clothingItem = InventoryItemFactory.CreateItem(itemType)
                                                       desc:setWornItem(bodyLocation, clothingItem)
                                                  end
                                           end
                                     end
                                end
                 end
            end

            -- we exclude some weird looking clothing combinations (can still manually be choosen if desired)
            if desc:getWornItem("Dress") then -- for example: when dress is worn, don't wear t-shirt or tank top
               desc:setWornItem("Tshirt", nil) 
               desc:setWornItem("TankTop", nil)
               desc:setWornItem("Sweater", nil)
            end
            if desc:getWornItem("Tshirt") then
               local shirt = desc:getWornItem("Tshirt"):getFullType()
               if shirt == "Base.Shirt_CropTopTINT" or shirt == "Base.Shirt_CropTopNoArmTINT" or shirt == "Base.BoobTube" then
                   desc:setWornItem("TankTop", nil)
               end
            end
            if desc:getWornItem("UnderwearExtra1") then
               desc:setWornItem("Socks", nil)
            end 
      end  
 
      -- also exclude weird clothing combinations for professions not having entries in the mod's clothing table
      if profession == "unemployed" or profession == "rasBotanist" or profession == "rasVeterinarian" or profession == "rasTailor" then 
           if desc:getWornItem("Dress") then 
               desc:setWornItem("Tshirt", nil) 
               desc:setWornItem("TankTop", nil)
            end
            if desc:getWornItem("Tshirt") then
                local shirt = desc:getWornItem("Tshirt"):getFullType()
                if shirt == "Base.Shirt_CropTopTINT" or shirt == "Base.Shirt_CropTopNoArmTINT" or shirt == "Base.BoobTube" then
                    desc:setWornItem("TankTop", nil)
                end
            end
      end
   
      
      -- randomly assign a hair style from table RasProfessionsTables.AvailableHairStyles
      local gender = "Male"
      if desc:isFemale() then
           gender = "Female"
      end
      if RasProfessionsTables["AvailableHairStyles"][gender][profession] then
         local styleTable = RasProfessionsTables["AvailableHairStyles"][gender][profession]         
         local style = styleTable[ZombRand(0, #styleTable) + 1]
         desc:getHumanVisual():setHairModel(style)
	     CharacterCreationHeader.instance.avatarPanel:setSurvivorDesc(desc)
      end



      -- in case of student or gang member, don't assign grey hair to them
      if profession == "rasStudent" or profession == "rasGangMember" then
            local youngColors = RasProfessionsTables.YoungColors
            local n = ZombRand(15) + 1
            local color = ImmutableColor.new(youngColors[n]["r"], youngColors[n]["g"], youngColors[n]["b"], 1)
            if color then
               desc:getHumanVisual():setHairColor(color)
	           desc:getHumanVisual():setBeardColor(color)
	           desc:getHumanVisual():setNaturalHairColor(color)
	           desc:getHumanVisual():setNaturalBeardColor(color)
	           CharacterCreationHeader.instance.avatarPanel:setSurvivorDesc(desc)
           end
        
      -- retired only gets grey hair colors
      elseif profession == "rasRetired" then
            local oldColors = RasProfessionsTables.OldColors
            local n = ZombRand(4) + 1
            local color = ImmutableColor.new(oldColors[n]["r"], oldColors[n]["g"], oldColors[n]["b"], 1)
            if color then
               desc:getHumanVisual():setHairColor(color)
	           desc:getHumanVisual():setBeardColor(color)
	           desc:getHumanVisual():setNaturalHairColor(color)
	           desc:getHumanVisual():setNaturalBeardColor(color)
	           CharacterCreationHeader.instance.avatarPanel:setSurvivorDesc(desc)
           end
      end      


end




