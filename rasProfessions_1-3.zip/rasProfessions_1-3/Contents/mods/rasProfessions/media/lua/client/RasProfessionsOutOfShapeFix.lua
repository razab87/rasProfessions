-- we manually manage the outOfShape trait if player hase choosen the Retired occupation; don't understand what the vanilla game is doing so I handle it manually  
--
--
-- by razab



RasProfessionsOutOfShapeFix = {}


function RasProfessionsOutOfShapeFix.FixIt(number)

         print("TEST OUTPUT - IN FIXIT")

         local player = getPlayer()
         if player:HasTrait("rasOutOfShapeProf") then
                 player:getTraits():remove("rasOutOfShapeProf")
                 --player:getTraits():remove("Out of Shape")
         end

         Events.OnTick.Remove(RasProfessionsOutOfShapeFix.FixIt) -- do this only on the first tick when new game starts
end






Events.OnTick.Add(RasProfessionsOutOfShapeFix.FixIt)
