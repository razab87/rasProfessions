-- we apply some necessary corrections to the user interface in the occupation and trait screen 
--
-- by razab


require "OptionScreens/CharacterCreationProfession"


RasProfessionsOccupationScreen = { } -- we'll add two new function to this file (see end of file)


-- remove "Perk = 0" stats from the overhauled vanilla professions in the xp boost window
local vanilla_checkXPBoost = CharacterCreationProfession.checkXPBoost
function CharacterCreationProfession:checkXPBoost(...)
         vanilla_checkXPBoost(self, ...)     -- execute vanilla function
         
         local profession = MainScreen.instance.desc:getProfession()        
         if profession == "policeofficer" then                 -- correct the ui for the professions manually; need to do this for only 5 professions
                   self.listboxXpBoost:removeItem("Nimble")
         end              
         if profession == "parkranger" then
                   self.listboxXpBoost:removeItem("Axe")
                   self.listboxXpBoost:removeItem("Carpentry")
         end          
         if profession == "repairman" then
                   self.listboxXpBoost:removeItem("Short Blunt")
         end   
         if profession == "engineer" then
                   self.listboxXpBoost:removeItem("Carpentry")
         end                   
         if profession == "mechanics" then
                   self.listboxXpBoost:removeItem("Short Blunt")
         end      
end

-- hide the "hidden" traits from the window showing the selected traits
local vanilla_onSelectProf = CharacterCreationProfession.onSelectProf
function CharacterCreationProfession:onSelectProf(item, ...)
         vanilla_onSelectProf(self, item, ...) -- execute vanilla function
         
         local profession = MainScreen.instance.desc:getProfession() 
         local prof = ProfessionFactory.getProfession(profession)        
         local traitList = prof:getFreeTraits()
         for j=1,traitList:size() do
             local traitName = traitList:get(j-1)
             local trait = TraitFactory.getTrait(traitName)
             local traitLabel = trait:getLabel()
             if RasProfessionsMain.isHiddenTrait(traitName) then -- don't show the hidden traits 
                 self.listboxTraitSelected:removeItem(traitLabel)
             end
         end
end
         
-- after players remove a trait, we must check whether they have a free trait; in that case, we must manually delete the excluded traits from the selection menu; otherwise, the excluded traits
-- could be displayed twice; this happens if the exluded trait is excluded by a free trait AND at the same time by a selected vanilla trait
local vanilla_removeTrait = CharacterCreationProfession.removeTrait
function CharacterCreationProfession:removeTrait(...) 
        vanilla_removeTrait(self, ...)  -- execute vanilla code

        local profession = MainScreen.instance.desc:getProfession() 
        local prof = ProfessionFactory.getProfession(profession)        
        local traitList = prof:getFreeTraits()
        for j=1, traitList:size() do
            local traitName = traitList:get(j-1)            
                 local trait = TraitFactory.getTrait(traitName)
                 for i = 0, trait:getMutuallyExclusiveTraits():size()-1 do                    
                     local exclusiveTraitName = trait:getMutuallyExclusiveTraits():get(0)
                     local exclusiveTrait = TraitFactory.getTrait(exclusiveTraitName)
                     if exclusiveTrait:getCost() > 0 then
                         self.listboxTrait:removeItem(exclusiveTrait:getLabel())
                     else
                         self.listboxBadTrait:removeItem(exclusiveTrait:getLabel())
                     end
                 end 
        end
        CharacterCreationMain.sort(self.listboxTrait.items);
        CharacterCreationMain.invertSort(self.listboxBadTrait.items);
end


-- we correct the profession descriptions in the drop down info window; this is necessary so that perk = 0 skills and hidden traits are not displayed; applies only to professions
-- which are changed or added by this mod (including vanilla professions)
local vanilla_populateProfessionList = CharacterCreationProfession.populateProfessionList
function CharacterCreationProfession:populateProfessionList(list, ...)	
       for _,profession in pairs(RasProfessionsMain.moddedProfessions) do -- only do this for professions affected by this mod           
		   local prof = ProfessionFactory.getProfession(profession)
		   if prof then
		      RasProfessionsOccupationScreen.SetRasProfessionDescription(prof) -- we overwrite the vanilla-style descriptions   
                  end
       end
	
       vanilla_populateProfessionList(self, list, ...) -- execute vanilla code       	
end


-- this will define the correct descriptions for our professions
function RasProfessionsOccupationScreen.SetRasProfessionDescription(prof)
        local profession = prof:getType()
	local desc = getTextOrNull("UI_profdesc_" .. profession) or ""
	if RasProfessionsMain.description[profession] then
	      if desc == "" then
	            desc = RasProfessionsMain.description[profession] -- add our new descriptions
	      else
	            desc = desc .. "\n" .. RasProfessionsMain.description[profession] -- add new description after vanilla description
	      end
	end
	local boost = transformIntoKahluaTable(prof:getXPBoostMap())
	local infoList = {}
	for perk,level in pairs(boost) do
		local perkName = PerkFactory.getPerkName(perk)
		-- "+1 Cooking" etc
		local levelStr = tostring(level:intValue())
		if level:intValue() > 0 then -- only show perks in drop down menu when greater than 0
		      levelStr = "+" .. levelStr
		      table.insert(infoList, { perkName = perkName, levelStr = levelStr })
		end
	end
	table.sort(infoList, function(a,b) return not string.sort(a.perkName, b.perkName) end)
	for _,info in ipairs(infoList) do
		     if desc ~= "" then desc = desc .. "\n" end
		     desc = desc .. info.levelStr .. " " .. info.perkName
	end
	local traits = prof:getFreeTraits()
	for j=1,traits:size() do
		--if desc ~= "" then desc = desc .. "\n" end
		local traitName = traits:get(j-1)
		local trait = TraitFactory.getTrait(traitName)
		local traitLabel = trait:getLabel()		
		
		if not RasProfessionsMain.isHiddenTrait(traitName) then -- do not show hidden traits in the profession's drop down window
		   if desc ~= "" then desc = desc .. "\n" end
		   desc = desc .. traitLabel
		end
	end
	prof:setDescription(desc)	
end




