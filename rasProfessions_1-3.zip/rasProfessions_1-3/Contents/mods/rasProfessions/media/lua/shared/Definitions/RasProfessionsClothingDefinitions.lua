-- here we define the clothing for the professions
--
--
-- by razab





RasProfessionsClothingDefinitions = { }

-- remove the denim shirt for women (men don't have them in default clothing so women shouldn't too); also remove the straps dresses since they don't fit really well as some everday clothing

RasProfessionsClothingDefinitions.default = {
           Female = {
               Shirt = { remove = {"Base.Shirt_Denim"}},
               Dress = { remove = {"Base.Dress_long_Straps", "Base.Dress_SmallStrapless", "Base.Dress_Straps", "Base.DressKnees_Straps", "Base.Dress_SmallStraps"}}
           }
}



-- the profession clothing

------------------------------------------------- vanilla professions:


RasProfessionsClothingDefinitions.fireofficer = {
        Female = { 
              Shirt = { items = { }, chance = 100},
        }, 
       Special = { -- defining this field has the result that the game will dress body location only with the clothing items listed below (e.g. no fedoras for firefigthers but baseball cap may occur; still possible to choose 
                   -- fedora during char creation); chance value should always be defined!; only necessary to use if chance < 100
            Female = {
                 Hat = { items = {"Base.Hat_BaseballCap"}, chance = 10 }
            }
       }

}


RasProfessionsClothingDefinitions.policeofficer = { 
        Female = { -- if female and male clothing should be the same, it is sufficient to define for female
              BeltExtra = { items = {"Base.HolsterSimple"}, chance = 100},
              Hat = { items = {"Base.Hat_Police", "Base.Hat_Police_Grey"}, chance = 100},
              Pants = { items = {"Base.Trousers_Police", "Base.Trousers_PoliceGrey"}, chance = 100},
              Shoes = { items = {"Base.Shoes_Random"}, chance = 100},
              Shirt = { items = {"Base.Shirt_OfficerWhite", "Base.Shirt_PoliceBlue", "Base.Shirt_PoliceGrey"}, chance = 100},
              Tshirt = { items = {"Base.Tshirt_PoliceGrey", "Base.Tshirt_PoliceBlue", "Base.Tshirt_Profession_PoliceBlue", "Base.Tshirt_Profession_PoliceWhite" }, chance = 100}
        } 
}

RasProfessionsClothingDefinitions.parkranger = {
     Female= {
        Hat = { items = {"Base.Hat_Ranger"}, chance = 100},
        Pants = { items = {"Base.Trousers_Ranger"}, chance = 100},
        Shoes = { items = {"Base.Shoes_Random"}, chance = 100},
        Shirt = { items = {"Base.Shirt_Ranger"}, chance = 100},
        Tshirt = { items = {"Base.Tshirt_Profession_RangerGreen", "Base.Tshirt_Profession_RangerBrown"}, chance = 100}
     }
}

RasProfessionsClothingDefinitions.constructionworker = {
     Female = {
        Hat = { items = {"Base.Hat_HardHat"}, chance = 100},
        Pants = { items = {"Base.Trousers_JeanBaggy"}, chance = 100},
        Shoes = { items = {"Base.Shoes_ArmyBoots"}, chance = 100},
        Shirt = { items = {"Base.Shirt_Denim", "Base.Shirt_Lumberjack"}, chance = 100},
        Tshirt = { items = { }, chance = 100},
        TorsoExtra = { items = {"Base.Vest_HighViz", "Base.Vest_Foreman"}, chance = 100}
     }
}

RasProfessionsClothingDefinitions.securityguard = {
    Female = {
       Hat = { items = { }, chance = 100},
       Pants = { items = {"Base.Trousers_Black"}, chance = 100},
       Shoes = { items = {"Base.Shoes_Random"}, chance = 100},
       Shirt = { items = {"Base.Shirt_FormalWhite"}, chance = 100},
    }
}

RasProfessionsClothingDefinitions.carpenter = {
     Female = {
        Eyes = { remove = {"Base.Glasses_SafetyGoggles"}},
        Pants = { items = {"Base.Trousers_JeanBaggy"}, chance = 100},
        Shirt = { items = {"Base.Shirt_Lumberjack"}, chance = 100},
        Shoes = { items = {"Base.Shoes_Random", "Base.Shoes_TrainerTINT"}, chance = 100},        
      },
      RemoveLocation = { Female = {"Mask"} }, -- this field is for removing a whole vanilla body location during the character creation (found some vanilla choices here a bit suboptimal, so...)
      Special = { 
            Female = {
                Hat = { items = {"Base.Hat_BaseballCap"}, chance = 10 }
            }
       }
}

RasProfessionsClothingDefinitions.burglar = {
   Female = {
      Hat = { items = {"Base.Hat_Beany"}, chance = 10 },
      Shoes = { items={"Base.Shoes_TrainerTINT"}, chance = 100},
      Pants = { items={"Base.Trousers_Denim"}, chance = 100},
      Shirt = { items={ }, chance = 100},
      TankTop = { items = { }, chance = 100},
      Sweater= { items = {"Base.HoodieDOWN_WhiteTINT"}, chance = 100}
   },
   RemoveLocation = { Female={"Mask", "MaskFull"} },
   Special = { 
            Female = {
                Hat = { items = {"Base.Hat_BaseballCap","Base.Hat_Beany"}, chance = 10 }
            }
   }
}

RasProfessionsClothingDefinitions.chef = {
   Female = {
      Hat = { items ={"Base.Hat_ChefHat"}, chance = 50},
      Pants = { items = {"Base.Trousers_Chef"}, chance = 100},
      Jacket = { items = {"Base.Jacket_Chef"}, chance = 100},
      TankTop = { items = { }, chance = 100},
   },
   Special = { 
            Female = {
                Hat = { items = {"Base.Hat_ChefHat"}, chance = 50 }
            }
   }
}

RasProfessionsClothingDefinitions.repairman = {
   Female = {
      Pants = { items = {"Base.Trousers_Denim"}, chance = 100},
      Shirt = { items = {"Base.Shirt_Denim", "Base.Shirt_Lumberjack"}, chance = 100}
   },
   Special = { 
            Female = {
                Hat = { items = {"Base.Hat_BaseballCap"}, chance = 10 }
            }
   }   
}

RasProfessionsClothingDefinitions.farmer = {
    Female = {
       Hat = { items = {"Base.Hat_Cowboy", "Base.Hat_SummerHat"}, chance = 10,},
       Pants = { items = {"Base.Dungarees"}, remove = { "Base.Trousers_Denim"}, chance = 100},
       Tshirt = { items = { }, chance = 100},
       TankTop = { items = { }},
       Shirt = { items = {"Base.Shirt_Lumberjack"}, remove = {"Base.Shirt_Denim"}, chance = 100},
       Torso1Legs1 = { items = {"Base.LongJohns"}, chance = 100}
    },
    Male = {
       Hat = { items = {"Base.Hat_Cowboy"}, chance = 10,},
       Pants = { items = {"Base.Dungarees"}, remove = { "Base.Trousers_Denim"}, chance = 100},
       Tshirt = { items = { }, chance = 100},
       TankTop = { items = { }, chance = 100},
       Shirt = { items = {"Base.Shirt_Lumberjack"}, remove = {"Base.Shirt_Denim"}, chance = 100},
       Torso1Legs1 = { items = {"Base.LongJohns"}, chance = 100}
    },
    Special = { 
            Female = {
                Hat = { items = {"Base.Hat_BaseballCap","Base.Hat_Cowboy", "Base.Hat_SummerHat"}, chance = 10 }
            },
            Male = {
                Hat = { items = {"Base.Hat_BaseballCap","Base.Hat_Cowboy"}, chance = 10 }
            },
     }

}

RasProfessionsClothingDefinitions.fisherman = {
    Female = {
        Hat = { items = {"Base.Hat_BucketHat", "Base.Hat_Beany", "Base.Hat_BonnieHat_CamoGreen"}, chance = 100},
        Pants = { items = {"Base.Trousers_JeanBaggy", "Base.Trousers_Denim"}, chance = 100},
        Shirt = { items = {"Base.Shirt_Lumberjack"}, remove = {"Base.Shirt_Denim"}, chance = 100},
        TorsoExtra = { items = {"Base.Vest_Hunting_Grey", "Base.Vest_Hunting_Camo", "Base.Vest_Hunting_CamoGreen" }, chance = 100}
    },
}


RasProfessionsClothingDefinitions.doctor = {
    Female = {
        Hat = { items = { }, remove = {"Base.Hat_SurgicalMask_Blue", "Base.Hat_SurgicalMask_Green"}, chance = 100 },
        Tshirt = { items = { }, chance = 100},
        Pants = { items = {"Base.Trousers_SuitTEXTURE", "Base.Trousers_Suit"}, chance = 100},
        Shirt = { items = {"Base.Shirt_FormalTINT"}, remove = {"Base.Shirt_FormalWhite"}, chance = 100},
        Jacket = { items = {"Base.JacketLong_Doctor"}, chance = 100},
        Shoes = { items = {"Base.Shoes_Random"}, chance = 100},
        Necklace = { items = {"Base.Necklace_Gold", "Base.Necklace_GoldRuby", "Base.Necklace_Silver", "Base.Necklace_Pearl", "Base.NecklaceLong_Gold", "Base.NecklaceLong_Silver"}, chance = 100},
        UnderwearExtra1 = { items = {"Base.TightsBlack", "Base.TightsBlackTrans", "Base.TightsBlackSemiTrans"}, chance = 50 },
    },
    Male = {
        Hat = { items = { }, remove = {"Base.Hat_SurgicalMask_Blue", "Base.Hat_SurgicalMask_Green"}, chance = 100 },
        Tshirt = { items = { }},
        Pants = { items = {"Base.Trousers_Suit"}, remove = { "Base.Trousers_SuitTEXTURE"}, chance = 100},
        Shirt = { items = {"Base.Shirt_FormalWhite"}, chance = 100},
        Jacket = { items = {"Base.JacketLong_Doctor"}, chance = 100},
        Shoes = { items = {"Base.Shoes_Random"}, chance = 100},
        Neck = { items = {"Base.Tie_BowTieWorn"}, chance = 100}
    }, 
    RemoveLocation = { Female = {"Hands","Neck"}, Male = {"Hands"} }
}

RasProfessionsClothingDefinitions.veteran = {
    Female = {
        Eyes = { remove = {"Base.Glasses_Shooting"}},
        Hat = { items = {"Base.Hat_BaseballCapArmy", "Base.Hat_BonnieHat_CamoGreen", "Base.Hat_Bandana", }, remove = {"Base.Hat_BeretArmy"}, chance = 10,},
        TankTop = { items = {"Base.Vest_DefaultTEXTURE_TINT"}, chance = 100}, 
        Tshirt = { items = {"Base.Tshirt_Rock", "Base.Tshirt_Profession_VeterenGreen", "Base.Tshirt_Profession_VeterenRed"}, chance = 100},
        Shirt =  { items = { }, remove = {"Base.Shirt_CamoGreen"}, chance = 100},
        Pants = { items = {"Base.Shorts_CamoGreenLong", "Base.Trousers_CamoDesert", "Base.Trousers_CamoGreen"}, chance = 100},
        Necklace = { items = {"Base.Necklace_DogTag"}, chance = 100}
    },
    Special = { 
            Female = {
                Hat = { items = {"Base.Hat_BaseballCap","Base.Hat_BaseballCapArmy", "Base.Hat_BonnieHat_CamoGreen", "Base.Hat_Bandana"}, chance = 10 }
            }
   } 
}

RasProfessionsClothingDefinitions.nurse = {
   Female = {
        Hat = { items = { }, remove = {"Hat_SurgicalCap_Blue", "Base.Hat_SurgicalCap_Green"}, chance = 100 }, 
        Shirt =  { items = {"Base.Shirt_Scrubs"}, chance = 100},
        Pants = { items = {"Base.Trousers_Scrubs"}, remove = {"Base.Trousers_DefaultTEXTURE_TINT"}, chance = 100},
        Shoes = { items = {"Base.Shoes_TrainerTINT"}, chance = 100},
   },
   RemoveLocation = { Female = {"Mask", "Hands"} }
}


RasProfessionsClothingDefinitions.lumberjack = {
     Female = {
        Hat = { items = {"Base.Hat_Beany"}, chance = 10,},
        Pants = { items = {"Base.Trousers_JeanBaggy"}, chance = 100},
        Shirt = { items = {"Base.Shirt_Lumberjack"}, remove = {"Base.Shirt_Denim"}, chance = 100},
        Shoes = { items = {"Base.Shoes_ArmyBoots"}, chance = 100},
     },
     Special = { 
            Female = {
                Hat = { items = {"Base.Hat_BaseballCap", "Base.Hat_Beany"}, chance = 10 }
            }
     }
}

RasProfessionsClothingDefinitions.fitnessInstructor = {
       Female = {
            Hat = {	items = {"Base.Hat_Sweatband",}, chance = 10,},
            TankTop = { items = {"Base.Vest_DefaultTEXTURE_TINT"}, chance = 100},
            Pants = { items = {"Base.Shorts_LongSport", "Base.Shorts_ShortSport"}, chance = 100},
            Tshirt = { items = {"Base.Tshirt_Sport"}, chance = 100},
            Shirt = { items = { }, chance = 100},
            Shoes = { items = {"Base.Shoes_TrainerTINT"}, chance = 100},
            Socks = { items = {"Base.Socks_Ankle"}, chance = 100},
       },
       Special = { 
            Female = {
                Hat = { items = {"Base.Hat_BaseballCap","Base.Hat_Sweatband"}, chance = 10 }
            }
       }
}

RasProfessionsClothingDefinitions.burgerflipper = {
     Female = {
          Hat = { items = {"Base.Hat_FastFood", "Base.Hat_FastFood_Spiffo"}, chance = 100},
          TankTop = { items = {"Base.Vest_DefaultTEXTURE_TINT"}, chance = 100},
          Pants = { items = {"Base.Trousers_DefaultTEXTURE_TINT", "Base.Trousers_Denim", "Base.Shorts_LongDenim", "Base.Shorts_ShortDenim", "Base.Shorts_ShortFormal"}, chance = 100},
          Tshirt = { items = {"Base.Tshirt_Rock", "Base.Tshirt_DefaultTEXTURE_TINT", "Base.Tshirt_BusinessSpiffo"}, chance = 100},
          Shirt = { items = { }, chance = 100},
          Shoes = { items = {"Base.Shoes_TrainerTINT"}, chance = 100},
     }
}

RasProfessionsClothingDefinitions.electrician = {
     Female = {
       Eyes = { remove = {"Base.Glasses_SafetyGoggles"}},
       Pants = { items = {"Base.Trousers_Denim"}, chance = 100},
       Shirt = { items = {"Base.Shirt_Denim", "Base.Shirt_Lumberjack"}, chance = 100}
     },
     RemoveLocation = { Female = {"Mask", "TorsoExtra"} },
     Special = { 
            Female = {
                Hat = { items = {"Base.Hat_BaseballCap"}, chance = 10 }
            }
     }
}

RasProfessionsClothingDefinitions.engineer = {
       Female = {
           Hat = { items = { }, remove = {"Base.Hat_DustMask"}, chance = 100 },
           Tshirt = { items = {"Base.Tshirt_DefaultTEXTURE_TINT"}, chance = 100},
           Pants = { items = {"Base.Trousers_DefaultTEXTURE_TINT", "Base.Trousers_Denim"}, remove = {"Base.Trousers_SuitTEXTURE"}, chance = 100 },
           Shirt = { items = {"Base.Shirt_FormalWhite", "Base.Shirt_FormalWhite_ShortSleeve"}, remove = {"Base.Shirt_FormalTINT"}, chance = 100},           
           Shoes = { items = {"Base.Shoes_Random"}, chance = 100},
       }, 
       Male = {
           Hat = { items = { }, remove = {"Base.Hat_DustMask"}, chance = 100 },
           Tshirt = { items = {"Base.Tshirt_DefaultTEXTURE_TINT"}, chance = 100},
           Shirt = { items = {"Base.Shirt_FormalWhite", "Base.Shirt_FormalWhite_ShortSleeve"}, remove = {"Base.Shirt_FormalTINT"}, chance = 100},
           Pants = { items = {"Base.Trousers_Denim"}, remove = {"Base.Trousers_SuitTEXTURE"}, chance = 100},
           Shoes = { items = {"Base.Shoes_Random"}, chance = 100},
           Neck = { items = {"Base.Tie_Full"}, chance = 30 },
	  },
      RemoveLocation = { Female = {"TorsoExtra","Neck"}, Male = {"TorsoExtra"} },
      Special = { 
            Male = {
                Hat = { items = {"Base.Hat_GolfHat", "Base.Hat_Fedora"}, chance = 10 }
            }
      }
}

RasProfessionsClothingDefinitions.metalworker = {
       Female = {
          Eyes = { remove = {"Base.Glasses_SafetyGoggles"}},
          Pants = { items = {"Base.Trousers_Denim", "Base.Trousers_JeanBaggy"}, chance = 100},
          Shirt = { items = {"Base.Shirt_Denim"}, remove = {"Base.Shirt_Lumberjack"}, chance = 100}
       },
       RemoveLocation = { Female = {"Mask", "TorsoExtra"} },
       Special = { 
            Female = {
                Hat = { items = {"Base.Hat_BaseballCap"}, chance = 10 }
            }
        }
}

RasProfessionsClothingDefinitions.mechanics = {
       Female = {	
          Eyes = { remove = {"Base.Glasses_SafetyGoggles"}},
          FullSuit = { items = {"Base.Boilersuit_BlueRed"}, chance = 100},
          Shirt = { items = { }, chance = 100}
       },
       RemoveLocation = { Female = {"Mask"} },
       Special = {
            Female = {
                Hat = { items = {"Base.Hat_Bandana", "Base.Hat_BaseballCap"}, chance = 10 }
            }
       }
}

--------------------------------------------------- new professions


RasProfessionsClothingDefinitions.rasTeacher = {
      Female = {
          Hat = { items = { }},
          Eyes = {items = {"Base.Glasses_Normal"}, chance = 40, },
          Tshirt = {items = {"Base.Tshirt_DefaultTEXTURE_TINT", "Base.Tshirt_PoloStripedTINT", "Base.Tshirt_PoloTINT", "Base.Tshirt_WhiteLongSleeveTINT"}, chance = 100},
          Pants = { items = {"Base.Trousers_DefaultTEXTURE_TINT", "Base.Trousers_Denim", "Base.Shorts_LongDenim", "Base.Trousers_Black"}, chance = 100},
          Skirt = { items = {"Base.Skirt_Knees", "Base.Skirt_Long", "Base.Skirt_Normal",}, chance = 50,},
          Dress = { items = {"Base.Dress_Normal", "Base.Dress_Knees", "Base.Dress_Long"}, chance = 10, },
          UnderwearExtra1 = { items = {"Base.TightsBlack", "Base.TightsBlackTrans", "Base.TightsBlackSemiTrans"}, chance = 30 },
      },
      Male = {
          Hat = { items = { }},
          Eyes = {items = {"Base.Glasses_Normal"}, chance = 40, },
          Pants = { items = {"Base.Trousers_Denim", "Base.Shorts_LongDenim", "Base.Trousers_Black"}, chance = 100},
      },
      Special = {
            Female = {
                Shirt = {items = {"Base.Shirt_FormalTINT", "Base.Shirt_FormalWhite_ShortSleeveTINT",}, chance = 30 }
            },
            Male = {
                Shirt = {items = {"Base.Shirt_FormalTINT", "Base.Shirt_FormalWhite_ShortSleeveTINT","Base.Shirt_HawaiianTINT"}, chance = 30 }
            }
      }      
}

-- botanist has no special clothing

RasProfessionsClothingDefinitions.rasWasteCollector = {
       Female = {
          Pants = { items = {"Base.Trousers_JeanBaggy"}},
          Shoes = { items = {"Base.Shoes_ArmyBoots"}},
          Shirt = { items = {"Base.Shirt_Denim"}},
          TorsoExtra = { items = {"Base.Vest_HighViz"}},
       },
       Special = {
            Female = {
                Hat = { items = {"Base.Hat_BaseballCap", "Base.Hat_Visor_WhiteTINT"}, chance = 10 }
            }
       }
}

RasProfessionsClothingDefinitions.rasStudent = {
      Female = {
         Back = { items = {"Base.Bag_Schoolbag"}}, 
         Tshirt = { items = {"Base.Tshirt_Rock", "Base.Tshirt_DefaultDECAL_TINT"}, chance = 30},
      },   
      Special = {
            Female = {
                Hat = { items = {"Base.Hat_BaseballCap", "Base.Hat_BucketHat", "Base.Hat_Fedora", "Base.Hat_Visor_WhiteTINT"}, chance = 20 }
            }
       }
}

RasProfessionsClothingDefinitions.rasDeliveryDriver = {
      Female = {
         TankTop = { items = {"Base.Vest_DefaultTEXTURE_TINT"}},
         Hat = { items = {"Base.Hat_BaseballCap"}},
         Tshirt = { items = {"Base.Tshirt_Rock", "Base.Tshirt_DefaultDECAL_TINT"}, chance = 30},
         Shirt = { items = {}},
         Pants = { items = {"Base.Trousers_DefaultTEXTURE_TINT", "Base.Trousers_Denim", "Base.Shorts_LongDenim", "Base.Shorts_ShortDenim", "Base.Shorts_ShortFormal"}},
         Shoes = { items = {"Base.Shoes_TrainerTINT"}},
      },
}

RasProfessionsClothingDefinitions.rasLibrarian = {
     Female = {
        Eyes = { items = {"Base.Glasses_Normal", "Base.Glasses_Reading"}},
        Hat = { items = { }},
        Tshirt = {items = {"Base.Tshirt_DefaultTEXTURE_TINT", "Base.Tshirt_PoloStripedTINT", "Base.Tshirt_PoloTINT", "Base.Tshirt_WhiteLongSleeveTINT"}, chance = 100},
        Pants = { items = {"Base.Trousers_DefaultTEXTURE_TINT", "Base.Trousers_Denim", "Base.Shorts_LongDenim", "Base.Trousers_Black"}, chance = 100},
        Skirt = { items = {"Base.Skirt_Knees", "Base.Skirt_Long", "Base.Skirt_Normal",}, chance = 50,},
        Dress = { items = {"Base.Dress_Normal", "Base.Dress_Knees", "Base.Dress_Long"}, chance = 10, },
        UnderwearExtra1 = { items = {"Base.TightsBlack", "Base.TightsBlackTrans", "Base.TightsBlackSemiTrans"}, chance = 30 },
      },
      Male = {
          Hat = { items = { }},
          Eyes = { items = {"Base.Glasses_Normal", "Base.Glasses_Reading"}},
          Pants = { items = {"Base.Trousers_DefaultTEXTURE_TINT","Base.Trousers_Denim", "Base.Shorts_LongDenim", "Base.Trousers_Black"}, chance = 100},
      },
      Special = {
            Female = {
                Shirt = {items = {"Base.Shirt_FormalTINT", "Base.Shirt_FormalWhite_ShortSleeveTINT",}, chance = 30 }
            },
            Male = {
                Shirt = {items = {"Base.Shirt_FormalWhite", "Base.Shirt_FormalWhite_ShortSleeve"}, chance = 30 }, 
                Hat = { items = {"Base.Hat_GolfHat", "Base.Hat_Fedora"}, chance = 10 }
            }
      }
}

RasProfessionsClothingDefinitions.rasPriest = {
     Female = {
        Hat = { items = { }},
        Pants = { items = {"Base.Trousers_Suit"}},
        Shoes = { items = {"Base.Shoes_Random"}},
        Shirt = { items = {"Base.Shirt_Priest"}},
     }
}

-- tailor has no special clothing

RasProfessionsClothingDefinitions.rasITProf = {
     Female = {
        Eyes = { items = {"Base.Glasses_Normal"}},
        Shirt = { items = {"Base.Shirt_FormalTINT", "Base.Shirt_FormalWhite_ShortSleeveTINT"}},
        Tshirt = { items = {"Base.Tshirt_IndieStoneDECAL"}},
        LeftWrist = { items = {"Base.WristWatch_Left_DigitalBlack"}},
        Pants = { items = {"Base.Trousers_DefaultTEXTURE_TINT", "Base.Trousers_Denim", "Base.Shorts_LongDenim", "Base.Shorts_ShortDenim", "Base.Shorts_ShortFormal"}},
        Skirt = { items = {"Base.Skirt_Knees", "Base.Skirt_Long", "Base.Skirt_Mini", "Base.Skirt_Normal", "Base.Skirt_Short"}, chance = 50},
     },
     Male = {
        Eyes = { items = {"Base.Glasses_Normal"}},
        Shirt = { items = {"Base.Shirt_FormalTINT", "Base.Shirt_FormalWhite_ShortSleeveTINT"}},
        Tshirt = { items = {"Base.Tshirt_IndieStoneDECAL"}},
        LeftWrist = { items = {"Base.WristWatch_Left_DigitalBlack"}},
     },
     Special = {
            Female = {
                Hat = { items = {"Base.Hat_BaseballCap", "Base.Hat_BucketHat", "Base.Hat_Fedora"}, chance = 10 }
            }
      }
}

RasProfessionsClothingDefinitions.rasArchitect = {      
      Female = {
           Hat = { items = { }},
           Tshirt = { items = {"Base.Tshirt_DefaultTEXTURE_TINT"}},
           Shirt = { items = {"Base.Shirt_FormalTINT", "Base.Shirt_FormalWhite_ShortSleeveTINT"}},
           Pants = { items = {"Base.Trousers_Black","Base.Trousers_DefaultTEXTURE_TINT", "Base.Trousers_Denim"}},
           Shoes = { items = {"Base.Shoes_Random"}}, 
           Necklace = { items = {"Base.Necklace_Gold", "Base.Necklace_GoldRuby", "Base.Necklace_Silver", "Base.Necklace_Pearl", "Base.NecklaceLong_Gold", "Base.NecklaceLong_Silver"}},
     }, 
     Male = {
           Hat = { items = { }},
           Tshirt = { items = {"Base.Tshirt_DefaultTEXTURE_TINT"}},
           Shirt = { items = {"Base.Shirt_FormalWhite", "Base.Shirt_FormalWhite_ShortSleeve"}},
           Pants = { items = {"Base.Trousers_Black", "Base.Trousers_Denim"}},
           Shoes = { items = {"Base.Shoes_Random"}},
           Neck = { items = {"Base.Tie_Full"}},
     },
     Special = {
            Male = {
                Hat = { items = {"Base.Hat_GolfHat", "Base.Hat_Fedora"}, chance = 10 }
            }
      }
}


RasProfessionsClothingDefinitions.rasVeterinarian = {
      Female = {
           Tshirt = { items = {"Base.Tshirt_DefaultTEXTURE_TINT", "Base.Tshirt_WhiteLongSleeveTINT", "Base.Tshirt_PoloStripedTINT", "Base.Tshirt_PoloTINT"}, chance = 100},
           Pants = { items = {"Base.Trousers_DefaultTEXTURE_TINT", "Base.Trousers_Denim", "Base.Shorts_LongDenim", "Base.Shorts_ShortDenim", "Base.Shorts_ShortFormal"}, chance = 100 },           
           Shoes = { items = {"Base.Shoes_Random", "Base.Shoes_TrainerTINT"}, chance = 100},
      }, 
      Special = { 
            Female = {
                Hat = { items = {"Base.Hat_BaseballCap"}, chance = 10 }
            },
            Male = {
                Hat = { items = {"Base.Hat_GolfHat", "Base.Hat_BaseballCap"}, chance = 10 }
            }
      }
}


RasProfessionsClothingDefinitions.rasOfficeEmployee = {
      Female = {
           Hat = { items = { }},
           Tshirt = { items = {"Base.Tshirt_DefaultTEXTURE_TINT"}},
           Shirt = { items = {"Base.Shirt_FormalTINT", "Base.Shirt_FormalWhite_ShortSleeveTINT"}},
           Pants = { items = {"Base.Trousers_SuitWhite","Base.Trousers_SuitTEXTURE"}},
           Skirt = { items = {"Base.Skirt_Knees", "Base.Skirt_Long", "Base.Skirt_Normal", "Base.Skirt_Short"}, chance = 50 },
           Dress = { items = {"Base.Dress_Knees"}, chance = 10, },
           Shoes = { items = {"Base.Shoes_BlackBoots", "Base.Shoes_Fancy"}},
           LeftWrist = { items = {"Base.WristWatch_Left_ClassicBlack"}}, 
           Necklace = { items = {"Base.Necklace_Gold", "Base.Necklace_GoldRuby", "Base.Necklace_Silver", "Base.Necklace_Pearl", "Base.NecklaceLong_Gold", "Base.NecklaceLong_Silver"}},
           UnderwearExtra1 = { items = {"Base.TightsBlack", "Base.TightsBlackTrans", "Base.TightsBlackSemiTrans"}},
           Socks = { items = { }},
     },
     Male = {
           Hat = { items = { }},
           Neck = { items = {"Base.Tie_Full"}},
           Shirt = { items = {"Base.Shirt_FormalWhite"}},
           Pants = { items = {"Base.Trousers_Suit"}},
           Shoes = { items = {"Base.Shoes_Random"}},
           LeftWrist = { items = {"Base.WristWatch_Left_ClassicBlack"}},
     },
     Special = {
            Male = {
                Hat = { items = {"Base.Hat_Fedora"}, chance = 10 }
            }
     }
    
}

RasProfessionsClothingDefinitions.rasHomeless = {
    Female = {
             TankTop = { items = { }},
             Hat = { items = {"Base.Hat_Beany"}},
             Jacket = { items = {"Base.JacketLong_Random"}},
             Shirt = { items = { }},
             Tshirt= { items = {"Base.Tshirt_DefaultTEXTURE_TINT"}},
             Pants = { items = {"Base.Trousers_Denim"}},
             Skirt = { items = {"Base.Skirt_Long"}, chance = 50 },
             Hands = { items = {"Base.Gloves_FingerlessGloves"}},
             Shoes = { items = {"Base.Shoes_Random", "Base.Shoes_TrainerTINT"}},
    },
    Male = {
             TankTop = { items = { }},
             Hat = { items = {"Base.Hat_Beany"}},
             Jacket = { items = {"Base.JacketLong_Random"}},
             Shirt = { items = { }},
             Tshirt= { items = {"Base.Tshirt_DefaultTEXTURE_TINT"}},
             Pants = { items = {"Base.Trousers_Denim"}},
             Shoes = { items = {"Base.Shoes_Random", "Base.Shoes_TrainerTINT"}},
             Hands = { items = {"Base.Gloves_FingerlessGloves"}},
   }
}

RasProfessionsClothingDefinitions.rasGangMember = {
   Female = {
             Hat = { items = {"Base.Hat_Bandana"}},
             Shirt = { items = {"Base.Shirt_Lumberjack"}},
             Tshirt = { items = {"Base.Tshirt_DefaultDECAL_TINT", "Base.Tshirt_Rock"}},
             Pants = { items = {"Base.Trousers_JeanBaggy", "Base.Shorts_CamoUrbanLong", "Base.Trousers_CamoUrban"}},
             Socks = { items = {"Base.Socks_Ankle"}},
             Shoes = { items = {"Base.Shoes_TrainerTINT"}},
   }
}

RasProfessionsClothingDefinitions.rasMailCarrier = {
   Female = {
             Hat = { items = {"Base.Hat_BaseballCap"}},
             Shirt = { items = {"Base.Shirt_FormalWhite_ShortSleeve"}},
             Tshirt = { items = {"Base.Tshirt_DefaultTEXTURE_TINT"}},
             Pants = { items = {"Base.Shorts_ShortFormal"}},
             Back = { items = {"Base.Bag_Satchel"}},
   }, 
}

RasProfessionsClothingDefinitions.rasPharmacist = {
   Female = {
        Hat = { items = { }},
        Tshirt = { items = { }},
        Pants = { items = {"Base.Trousers_SuitTEXTURE", "Base.Trousers_Suit"}},
        Shirt = { items = {"Base.Shirt_FormalTINT"}},
        Jacket = { items = {"Base.JacketLong_Doctor"}},
        Shoes = { items = {"Base.Shoes_Random"}},
        UnderwearExtra1 = { items = {"Base.TightsBlack", "Base.TightsBlackTrans", "Base.TightsBlackSemiTrans"}, chance = 30},
        Necklace = { items = {"Base.Necklace_Gold", "Base.Necklace_GoldRuby", "Base.Necklace_Silver", "Base.Necklace_Pearl", "Base.NecklaceLong_Gold", "Base.NecklaceLong_Silver"}},
   },
   Male = {
        Hat = { items = { }},
        Tshirt = { items = { }},
        Pants = { items = {"Base.Trousers_Suit"}},
        Shirt = { items = {"Base.Shirt_FormalWhite"}},
        Jacket = { items = {"Base.JacketLong_Doctor"}},
        Shoes = { items = {"Base.Shoes_Random"}},
  },
}



RasProfessionsClothingDefinitions.rasRetired = {
   Female = {
        Hat = { items = { }},
        Tshirt = { items = { }},
        Shirt = { items = { }},
        TankTop = { items = {"Base.Vest_DefaultTEXTURE_TINT"}},
        Sweater = { items = {"Base.Jumper_DiamondPatternTINT", "Base.Jumper_VNeck"}},
        Eyes = { items = {"Base.Glasses_Reading"}},
        Pants = { items = {"Base.Trousers_DefaultTEXTURE_TINT"}},
        Skirt = { items = {"Base.Skirt_Normal"}, chance = 30 },
        Dress = { items = {"Base.Dress_Normal"}, chance = 30, }, 
        Shoes = { items = {"Base.Shoes_Sandals"}}, 
        Socks = { items = {"Base.Socks_Long"} },       
   },
   Male = {
        Hat = { items = { }},
        Tshirt = { items = { }},
        Shirt = { items = { }},
        TankTop = { items = {"Base.Vest_DefaultTEXTURE_TINT"}},
        Eyes = { items = {"Base.Glasses_Reading"}},
        Pants = { items = {"Base.Trousers_DefaultTEXTURE_TINT"}},        
        Sweater = { items = {"Base.Jumper_DiamondPatternTINT", "Base.Jumper_VNeck"}},
        Shoes = { items = {"Base.Shoes_Sandals"}},
        Socks = { items = {"Base.Socks_Long"} },
  },
  Special = { 
          Male = {
              Hat = { items = {"Base.Hat_GolfHat"}, chance = 10 }
          }
  }
}























