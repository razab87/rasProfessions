-- here we do the following:
--      * adding new professions and changing to the vanilla ones; all that happens in DoRasProfessions()
--      * adding some new custom traits which can be assigned as free traits to the professions; we also add some "hidden" traits which are not shown in the interface and allow us to exclude certain 
--        professions from choosing certain traits (e.g. no illiterate doctors!); done in DoRasTraits()
--      * appending the new profession clothes to the vanilla ones; this happens mainly in DoRasClothing() (which is called by DoRasProfessions())
--      * bringing all that into game via lua events (see end of this file)
--
-- by razab


require "ISHotbar"

RasProfessionsMain = { }


----------- we add the traits; they get exchanged with the corresponding vanilla traits on new game start (i've taken that clever idea from one of FenrisWolf's mods; thx!)
----------- we also add the "hidden" traits here
local traitsToSwap = { }  
local hiddenTraits = { }
function RasProfessionsMain.DoRasTraits()
                  
----------- vanilla traits for professions:                 
         TraitFactory.addTrait("rasOutdoorsmanProf", getText("UI_trait_outdoorsman"), 0, getText("UI_trait_outdoorsmandesc"), true) -- for parkranger, mail carrier
         table.insert(traitsToSwap, { swap = "rasOutdoorsmanProf", with = "Outdoorsman" } )
         TraitFactory.setMutualExclusive("rasOutdoorsmanProf", "Outdoorsman")
                                          
         TraitFactory.addTrait("rasFastReaderProf", getText("UI_trait_FastReader"), 0, getText("UI_trait_FastReaderDesc"), true) -- for teacher, librarian
         table.insert(traitsToSwap, { swap = "rasFastReaderProf", with = "FastReader" } )    
         TraitFactory.setMutualExclusive("rasFastReaderProf", "FastReader")    
         TraitFactory.setMutualExclusive("rasFastReaderProf", "SlowReader")    
         TraitFactory.setMutualExclusive("rasFastReaderProf", "Illiterate") 
                         
         TraitFactory.addTrait("rasHerbalistProf", getText("UI_trait_Herbalist"), 0, getText("UI_trait_HerbalistDesc"), true) -- for botanist, pharmacist
         table.insert(traitsToSwap, { swap = "rasHerbalistProf", with = "Herbalist" } )
         TraitFactory.setMutualExclusive("rasHerbalistProf", "Herbalist")  
                  
         TraitFactory.addTrait("rasResilientProf", getText("UI_trait_resilient"), 0, getText("UI_trait_resilientdesc"), true) -- for waste collector
         table.insert(traitsToSwap, { swap = "rasResilientProf", with = "Resilient" } )
         TraitFactory.setMutualExclusive("rasResilientProf", "Resilient") 
         TraitFactory.setMutualExclusive("rasResilientProf", "ProneToIllness");
                  
         TraitFactory.addTrait("rasFastLearnerProf", getText("UI_trait_FastLearner"), 0, getText("UI_trait_FastLearnerDesc"), true) -- for student         
         table.insert(traitsToSwap, { swap = "rasFastLearnerProf", with = "FastLearner" } )
         TraitFactory.setMutualExclusive("rasFastLearnerProf", "FastLearner");
         TraitFactory.setMutualExclusive("rasFastLearnerProf", "SlowLearner");
                  
         TraitFactory.addTrait("rasSpeedDemonProf", getText("UI_trait_SpeedDemon"), 0, getText("UI_trait_SpeedDemonDesc"), true) -- for delivery driver
         table.insert(traitsToSwap, { swap = "rasSpeedDemonProf", with = "SpeedDemon" } )
         TraitFactory.setMutualExclusive("rasSpeedDemonProf", "SpeedDemon");
         TraitFactory.setMutualExclusive("rasSpeedDemonProf", "SundayDriver");
                  
         TraitFactory.addTrait("rasPacifistProf", getText("UI_trait_Pacifist"), 0, getText("UI_trait_PacifistDesc"), true);
         table.insert(traitsToSwap, { swap = "rasPacifistProf", with = "Pacifist" } )
         TraitFactory.setMutualExclusive("rasPacifistProf", "Pacifist");
         TraitFactory.setMutualExclusive("rasPacifistProf", "Brawler");
                        
         TraitFactory.addTrait("rasDextrousProf", getText("UI_trait_Dexterous"), 0, getText("UI_trait_DexterousDesc"), true);
         table.insert(traitsToSwap, { swap = "rasDextrousProf", with = "Dextrous" } )
         TraitFactory.setMutualExclusive("rasDextrousProf", "Dextrous");
         TraitFactory.setMutualExclusive("rasDextrousProf", "AllThumbs");
                  
         TraitFactory.addTrait("rasNeedsLessSleepProf", getText("UI_trait_LessSleep"), 0, getText("UI_trait_LessSleepDesc"), true);
         table.insert(traitsToSwap, { swap = "rasNeedsLessSleepProf", with = "NeedsLessSleep" } )
         TraitFactory.setMutualExclusive("rasNeedsLessSleepProf", "NeedsLessSleep");
         TraitFactory.setMutualExclusive("rasNeedsLessSleepProf", "NeedsMoreSleep");
                  
         TraitFactory.addTrait("rasOrganizedProf", getText("UI_trait_Packmule"), 0, getText("UI_trait_PackmuleDesc"), true);
         table.insert(traitsToSwap, { swap = "rasOrganizedProf", with = "Organized" } )
         TraitFactory.setMutualExclusive("rasOrganizedProf", "Organized");
         TraitFactory.setMutualExclusive("rasOrganizedProf", "Disorganized");
                  
         TraitFactory.addTrait("rasThickSkinnedProf", getText("UI_trait_thickskinned"), 0, getText("UI_trait_thickskinneddesc"), true);
         table.insert(traitsToSwap, { swap = "rasThickSkinnedProf", with = "ThickSkinned" } )
         TraitFactory.setMutualExclusive("rasThickSkinnedProf", "ThickSkinned");
         TraitFactory.setMutualExclusive("rasThickSkinnedProf", "Thinskinned");


         local outOfShape = TraitFactory.addTrait("rasOutOfShapeProf", getText("UI_trait_outofshape"), 0, getText("UI_rasProfessions_rasOutOfShapeProf_descr"), true);
         outOfShape:addXPBoost(Perks.Fitness, -2)
         table.insert(traitsToSwap, { swap = "rasOutOfShapeProf", with = "Out of Shape" } )
         TraitFactory.setMutualExclusive("Athletic", "rasOutOfShapeProf")
         TraitFactory.setMutualExclusive("Fit", "rasOutOfShapeProf")
         TraitFactory.setMutualExclusive("Unfit", "rasOutOfShapeProf")
         TraitFactory.setMutualExclusive("rasOutOfShapeProf", "Out of Shape")
                           

----------- hidden traits; they are not shown in interface:                   
         TraitFactory.addTrait("rasNoIlliterate", getText("rasNoIlliterate"), 0, getText(""), true);
         table.insert(hiddenTraits, "rasNoIlliterate" )
         TraitFactory.setMutualExclusive("rasNoIlliterate", "Illiterate");
         
         TraitFactory.addTrait("rasNoPacifist", getText("rasNoPacifist"), 0, getText(""), true);
         table.insert(hiddenTraits, "rasNoPacifist" )
         TraitFactory.setMutualExclusive("rasNoPacifist", "Pacifist");
         
         TraitFactory.addTrait("rasNoFishing", getText("rasNoFishing"), 0, getText(""), true);
         table.insert(hiddenTraits, "rasNoFishing" )
         TraitFactory.setMutualExclusive("rasNoFishing", "Fishing");
         
         TraitFactory.addTrait("rasNoTailor", getText("rasNoTailor"), 0, getText(""), true);
         table.insert(hiddenTraits, "rasNoTailor" )
         TraitFactory.setMutualExclusive("rasNoTailor", "Tailor");
         
         TraitFactory.addTrait("rasNoGardener", getText("rasNoGardener"), 0, getText(""), true);
         table.insert(hiddenTraits, "rasNoGardener" )
         TraitFactory.setMutualExclusive("rasNoGardener", "Gardener");
         
         TraitFactory.addTrait("rasNoFirstAid", getText("rasNoFirstAid"), 0, getText(""), true);
         table.insert(hiddenTraits, "rasNoFirstAid" )
         TraitFactory.setMutualExclusive("rasNoFirstAid", "FirstAid");
                  
         table.insert(hiddenTraits, "Cook2" )     -- also mark the vanilla profession versions of traits as hidden (they have the same purpose as our "hidden" traits)  
         table.insert(hiddenTraits, "Mechanics2")
         
         
         TraitFactory.setMutualExclusive("Pacifist", "Brawler"); -- we make vanilla pacifist and vanilla brawler mutually exclusive (... cause otherwise makes no sense ;) )
                  
end





function RasProfessionsMain.isHiddenTrait(trait) -- test if a given trait is a hidden one (called in SetRasProfessionDescription below)
         for i,v in pairs(hiddenTraits) do
             if v == trait then
                return true
             end
         end
         return false
end         








local inventory = { }  
RasProfessionsMain.description = { } -- profession's descriptions need to be global since we'll use in this mod's file media/lua/client/OptionScreens/RasProfessionsOccupationScreen.lua
RasProfessionsMain.moddedProfessions = { } -- same is true for the professions changed/created by this mod


-------------------------- change vanilla professions and define new ones
function RasProfessionsMain.DoRasProfessions() 

------------------------------------- overhauled vanilla professions:

    local firefighter = ProfessionFactory.getProfession("fireofficer")
    firefighter:setName(getText("UI_rasProfessions_firefighter")) 
    table.insert(RasProfessionsMain.moddedProfessions, "fireofficer") -- we collect all vanilla and new professions for later interface management
    
    
    local policeofficer = ProfessionFactory.getProfession("policeofficer")
    policeofficer:setCost(-6) 
    policeofficer:addXPBoost(Perks.Nimble, 0)
    policeofficer:addFreeTrait("rasNoIlliterate") -- police officers shouldn't be illiterate!; hidden traits should be added after visible traits in order to avoid clunky interface btw 
    inventory.policeofficer = { "Base.Bullets45" } -- gun gets added on game start (below in CreatePlayer) 
    RasProfessionsMain.description.policeofficer = getText("UI_rasProfessions_policeofficer_descr")
    table.insert(RasProfessionsMain.moddedProfessions, "policeofficer")    
        
        
    local parkranger = ProfessionFactory.getProfession("parkranger")
    parkranger:setCost(-2) 
    parkranger:addXPBoost(Perks.Woodwork, 0) 
    parkranger:addXPBoost(Perks.Axe, 0)
    parkranger:addFreeTrait("rasOutdoorsmanProf");
    table.insert(RasProfessionsMain.moddedProfessions, "parkranger") 
     
     
    local constructionworker = ProfessionFactory.getProfession("constructionworker")
    constructionworker:setCost(-4) 
    RasProfessionsMain.description.constructionworker = getText("UI_rasProfessions_constructionworker_descr")
    table.insert(RasProfessionsMain.moddedProfessions, "constructionworker")
        
        
    local securityguard = ProfessionFactory.getProfession("securityguard")
    securityguard:setCost(-2) 
    securityguard:addXPBoost(Perks.Lightfoot, 1)
    securityguard:addXPBoost(Perks.Sprinting, 2)
    -- nightstick gets added on game start (below in CreatePlayer)
    RasProfessionsMain.description.securityguard = getText("UI_rasProfessions_securityguard_descr")
    table.insert(RasProfessionsMain.moddedProfessions, "securityguard")
    
    
    inventory.carpenter = { "Base.Hammer", "Base.Nails", "Base.Nails" }
    RasProfessionsMain.description.carpenter = getText("UI_rasProfessions_carpenter_descr")
    table.insert(RasProfessionsMain.moddedProfessions, "carpenter")
    
        
    inventory.chef = { "Base.KitchenKnife" }
    RasProfessionsMain.description.chef = getText("UI_rasProfessions_chef_descr")
    table.insert(RasProfessionsMain.moddedProfessions, "chef")  
      
            
    local repairman = ProfessionFactory.getProfession("repairman")
    repairman:setName(getText("UI_rasProfessions_janitor")) 
    repairman:addXPBoost(Perks.Maintenance, 3)
    repairman:addXPBoost(Perks.Woodwork, 1)
    repairman:addXPBoost(Perks.Electricity, 1)
    repairman:addXPBoost(Perks.SmallBlunt, 0)
    inventory.repairman = { "Base.Screwdriver" }
    RasProfessionsMain.description.repairman = getText("UI_rasProfessions_repairman_descr")
    table.insert(RasProfessionsMain.moddedProfessions, "repairman")    
        
        
    local farmer = ProfessionFactory.getProfession("farmer") 
    farmer:addFreeTrait("rasNoGardener")
    RasProfessionsMain.description.farmer = getText("UI_rasProfessions_farmer_descr")
    table.insert(RasProfessionsMain.moddedProfessions, "farmer")    
        
        
    local fisherman = ProfessionFactory.getProfession("fisherman")
    fisherman:setCost(0)
    fisherman:addFreeTrait("rasNoFishing")
    inventory.fisherman = { "Base.FishingRod" }
    RasProfessionsMain.description.fisherman = getText("UI_rasProfessions_fisherman_descr")
    table.insert(RasProfessionsMain.moddedProfessions, "fisherman")


    local doctor = ProfessionFactory.getProfession("doctor")
    inventory.doctor = { "Base.Pills" }
    doctor:addFreeTrait("rasNoIlliterate")
    doctor:addFreeTrait("rasNoFirstAid")
    RasProfessionsMain.description.doctor = getText("UI_rasProfessions_doctor_descr")
    table.insert(RasProfessionsMain.moddedProfessions, "doctor")   
       
        
    local nurse = ProfessionFactory.getProfession("nurse")
    nurse:setCost(4)
    table.insert(RasProfessionsMain.moddedProfessions, "nurse")
    
    
    -- no changes to lumberjack
   
    -- no changes to fitnessInstructor
    
    table.insert(RasProfessionsMain.moddedProfessions, "burgerflipper")
    
    -- no changes to electrician
    
            
    local engineer = ProfessionFactory.getProfession("engineer")
    engineer:setCost(-6)
    engineer:addXPBoost(Perks.Mechanics, 1)
    engineer:addXPBoost(Perks.Woodwork, 0)
    engineer:addFreeTrait("rasNoIlliterate")
    engineer:getFreeRecipes():add("Generator")
    RasProfessionsMain.description.engineer = getText("UI_rasProfessions_engineer_descr")
    table.insert(RasProfessionsMain.moddedProfessions, "engineer") 
    
            
    local metalworker = ProfessionFactory.getProfession("metalworker")
    metalworker:setCost(-4)
    inventory.metalworker = { "Base.WeldingMask" }
    RasProfessionsMain.description.metalworker = getText("UI_rasProfessions_metalworker_descr")
    table.insert(RasProfessionsMain.moddedProfessions, "metalworker")
    
        
    local mechanics = ProfessionFactory.getProfession("mechanics")
    mechanics:addXPBoost(Perks.SmallBlunt, 0)
    inventory.mechanics = { "Base.Wrench" }
    RasProfessionsMain.description.mechanics = getText("UI_rasProfessions_mechanics_descr")
    table.insert(RasProfessionsMain.moddedProfessions, "mechanics")
    

----------------------- new professions:  

    local teacher = ProfessionFactory.addProfession("rasTeacher", getText("UI_rasProfessions_rasTeacher"), "icon_rasTeacher", 6)
    teacher:addXPBoost(Perks.Doctor, 1) 
    teacher:addFreeTrait("rasFastReaderProf")
    table.insert(RasProfessionsMain.moddedProfessions, "rasTeacher")    
        
        
    local botanist = ProfessionFactory.addProfession("rasBotanist", getText("UI_rasProfessions_rasBotanist"), "icon_rasBotanist", -4)
    botanist:addXPBoost(Perks.PlantScavenging, 2)
    botanist:addXPBoost(Perks.Farming, 2)
    botanist:addFreeTrait("rasHerbalistProf")
    botanist:addFreeTrait("rasNoIlliterate")
    botanist:getFreeRecipes():add("Make Mildew Cure")
    botanist:getFreeRecipes():add("Make Flies Cure")
    botanist:getFreeRecipes():add("Herbalist")
    RasProfessionsMain.description.rasBotanist = getText("UI_rasProfessions_rasBotanist_descr")
    table.insert(RasProfessionsMain.moddedProfessions, "rasBotanist") 
     
        
    local wastecollector = ProfessionFactory.addProfession("rasWasteCollector", getText("UI_rasProfessions_rasWasteCollector"), "icon_rasWasteCollector", 4)
    wastecollector:addXPBoost(Perks.Strength, 1)
    wastecollector:addFreeTrait("rasResilientProf")
    inventory.rasWasteCollector = { "Base.Garbagebag" }
    RasProfessionsMain.description.rasWasteCollector = getText("UI_rasProfessions_rasWasteCollector_descr")
    table.insert(RasProfessionsMain.moddedProfessions, "rasWasteCollector")
    
       
    local student = ProfessionFactory.addProfession("rasStudent", getText("UI_rasProfessions_rasStudent"), "icon_rasStudent", 2)
    student:addXPBoost(Perks.Fitness, 1)
    student:addFreeTrait("rasFastLearnerProf")
    RasProfessionsMain.description.rasStudent = getText("UI_rasProfessions_rasStudent_descr")
    table.insert(RasProfessionsMain.moddedProfessions, "rasStudent")  
      
        
    local deliverydriver = ProfessionFactory.addProfession("rasDeliveryDriver", getText("UI_rasProfessions_rasDeliveryDriver"), "icon_rasDeliveryDriver", 0)
    deliverydriver:addXPBoost(Perks.Fitness, 1)
    deliverydriver:addXPBoost(Perks.Sprinting, 1)
    deliverydriver:addXPBoost(Perks.Lightfoot, 1)
    deliverydriver:addXPBoost(Perks.Nimble, 1)
    deliverydriver:addFreeTrait("rasSpeedDemonProf")
    table.insert(RasProfessionsMain.moddedProfessions, "rasDeliveryDriver") 
     
        
    local librarian = ProfessionFactory.addProfession("rasLibrarian", getText("UI_rasProfessions_rasLibrarian"), "icon_rasLibrarian", 2)
    librarian:addXPBoost(Perks.Lightfoot, 3)
    librarian:addFreeTrait("rasFastReaderProf")
    table.insert(RasProfessionsMain.moddedProfessions, "rasLibrarian")
    
        
    local priest = ProfessionFactory.addProfession("rasPriest", getText("UI_rasProfessions_rasPriest"), "icon_rasPriest", 14)
    priest:addFreeTrait("rasPacifistProf")
    priest:addFreeTrait("rasNoIlliterate")
    table.insert(RasProfessionsMain.moddedProfessions, "rasPriest")   
       
        
    local tailor = ProfessionFactory.addProfession("rasTailor", getText("UI_rasProfessions_rasTailor"), "icon_rasTailor", -2)
    tailor:addXPBoost(Perks.Tailoring, 3)
    tailor:addXPBoost(Perks.SmallBlade, 1)
    tailor:addFreeTrait("rasDextrousProf")
    tailor:addFreeTrait("rasNoTailor")
    inventory.rasTailor = { "Base.Needle", "Base.Thread", "Base.Scissors" }
    RasProfessionsMain.description.rasTailor = getText("UI_rasProfessions_rasTailor_descr")
    table.insert(RasProfessionsMain.moddedProfessions, "rasTailor")
    
        
    local itprofessional = ProfessionFactory.addProfession("rasITProf", getText("UI_rasProfessions_rasITProf"), "icon_rasITProf", 6)
    itprofessional:addXPBoost(Perks.Electricity, 1)
    itprofessional:addFreeTrait("rasNeedsLessSleepProf")
    itprofessional:addFreeTrait("rasNoIlliterate")
    RasProfessionsMain.description.rasITProf = getText("UI_rasProfessions_rasITProf_descr")
    table.insert(RasProfessionsMain.moddedProfessions, "rasITProf") 
     
        
    local architect = ProfessionFactory.addProfession("rasArchitect", getText("UI_rasProfessions_rasArchitect"), "icon_rasArchitect", -4)
    architect:addXPBoost(Perks.Woodwork, 2)
    architect:addXPBoost(Perks.MetalWelding, 2)
    architect:addFreeTrait("rasNoIlliterate")
    architect:getFreeRecipes():add("Make Metal Walls") 
    architect:getFreeRecipes():add("Make Metal Fences") 
    architect:getFreeRecipes():add("Make Metal Roof")
    RasProfessionsMain.description.rasArchitect = getText("UI_rasProfessions_rasArchitect_descr")
    table.insert(RasProfessionsMain.moddedProfessions, "rasArchitect") 
     
        
    local veterinarian = ProfessionFactory.addProfession("rasVeterinarian", getText("UI_rasProfessions_rasVeterinarian"), "icon_rasVeterinarian", 0)
    veterinarian:addXPBoost(Perks.Doctor, 2)
    veterinarian:addXPBoost(Perks.Trapping, 1)
    veterinarian:addXPBoost(Perks.SmallBlade, 1)
    veterinarian:addFreeTrait("rasNoIlliterate")
    table.insert(RasProfessionsMain.moddedProfessions, "rasVeterinarian") 
     
        
    local officeemployee = ProfessionFactory.addProfession("rasOfficeEmployee", getText("UI_rasProfessions_rasOfficeEmployee"), "icon_rasOfficeEmployee", 4)
    officeemployee:addFreeTrait("rasOrganizedProf")
    officeemployee:addFreeTrait("rasNoIlliterate")
    -- we add inventory items in CreatePlayer() below
    RasProfessionsMain.description.rasOfficeEmployee = getText("UI_rasProfessions_rasOfficeEmployee_descr")
    table.insert(RasProfessionsMain.moddedProfessions, "rasOfficeEmployee")  
      
        
    local homeless = ProfessionFactory.addProfession("rasHomeless", getText("UI_rasProfessions_rasHomeless"), "icon_rasHomeless", 0)
    homeless:addXPBoost(Perks.PlantScavenging, 1)
    homeless:addFreeTrait("rasThickSkinnedProf")
    inventory.rasHomeless = { "Base.WaterBottleEmpty" }  -- we add the garbage in CreatePlayer() below
    RasProfessionsMain.description.rasHomeless = getText("UI_rasProfessions_rasHomeless_descr")
    table.insert(RasProfessionsMain.moddedProfessions, "rasHomeless")    
        
        
    local gangmember = ProfessionFactory.addProfession("rasGangMember", getText("UI_rasProfessions_rasGangMember"), "icon_rasGangMember", -6) 
    gangmember:addXPBoost(Perks.Blunt, 2)
    gangmember:addXPBoost(Perks.SmallBlade, 2)
    gangmember:addXPBoost(Perks.Aiming, 1)
    gangmember:addFreeTrait("rasNoPacifist")
    table.insert(RasProfessionsMain.moddedProfessions, "rasGangMember")
    
        
    local mailcarrier = ProfessionFactory.addProfession("rasMailCarrier", getText("UI_rasProfessions_rasMailCarrier"), "icon_rasMailCarrier", 4) 
    mailcarrier:addXPBoost(Perks.Fitness, 1)
    mailcarrier:addXPBoost(Perks.Sprinting, 2)
    mailcarrier:addFreeTrait("rasOutdoorsmanProf")
    RasProfessionsMain.description.rasMailCarrier = getText("UI_rasProfessions_rasMailCarrier_descr")
    table.insert(RasProfessionsMain.moddedProfessions, "rasMailCarrier") 
     
        
    local pharmacist = ProfessionFactory.addProfession("rasPharmacist", getText("UI_rasProfessions_rasPharmacist"), "icon_rasPharmacist", 0)
    pharmacist:addXPBoost(Perks.Doctor, 2)
    pharmacist:getFreeRecipes():add("Herbalist")
    pharmacist:addFreeTrait("rasHerbalistProf")
    pharmacist:addFreeTrait("rasNoIlliterate")
    inventory.rasPharmacist = { "Base.Antibiotics" }
    RasProfessionsMain.description.rasPharmacist = getText("UI_rasProfessions_rasPharmacist_descr")
    table.insert(RasProfessionsMain.moddedProfessions, "rasPharmacist")


    local retired = ProfessionFactory.addProfession("rasRetired", getText("UI_rasProfessions_rasRetired"), "icon_rasRetired", 16)
    retired:addFreeTrait("rasOutOfShapeProf")
    table.insert(RasProfessionsMain.moddedProfessions, "rasRetired") 
     
        
    local profList = ProfessionFactory.getProfessions() 
    local group = BodyLocations.getGroup("Human")
    local allLocations = group:getAllLocations()
    for i=1,profList:size() do            -- interface mangament (as in vanilla) and adding clothing
		local prof = profList:get(i-1)
		BaseGameCharacterDetails.SetProfessionDescription(prof) -- interface: vanilla function for adding profession's description; the descriptions will be changed and corrected in 
		                                                        -- RasProfessionsOccupationScreen.SetRasProfessionDescription (see client folder)
                RasProfessionsMain.DoRasClothing(prof) -- profession clothing
    end 
    RasProfessionsMain.DoRasClothing("default") -- default clothing           
end  




-- the next four functions will add the profession clothing; the main function is DoRasClothing(); the preceding three are auxiliary

-- this function will help us working with the vanilla clothing table (ClothingSelectionDefinitions); in case a slot is not defined, we initialise it with an empty list { }
function RasProfessionsMain.InitClothingSlot(profession,gender,bodyLocation) -- note: variable profession might contain the value "default" for default clothing
         local vanillaDefs = ClothingSelectionDefinitions
         if not vanillaDefs[profession] then 
                    vanillaDefs[profession] = { }
                    vanillaDefs[profession][gender] = { }
                    vanillaDefs[profession][gender][bodyLocation] = { items = { } } 
         elseif not vanillaDefs[profession][gender] then
                    vanillaDefs[profession][gender] = { }
                    vanillaDefs[profession][gender][bodyLocation] = { items = { } }
         elseif not vanillaDefs[profession][gender][bodyLocation] then
                    vanillaDefs[profession][gender][bodyLocation] = { items = { } }  

         end                
end

function RasProfessionsMain.Contains(myTable,value) -- auxiliary function: check whether table contains value 
         for i,v in pairs(myTable) do
               if v == value then return true end
         end
         return false
end

function RasProfessionsMain.RemoveByValue(myTable,value) -- auxiliary function: remove value from table
         for i,v in pairs(myTable) do
             if v == value then
                table.remove(myTable,i)
             end
         end
end
 
function RasProfessionsMain.RemoveField(myTable, index) -- auxiliary function: remove field from table
    for i,_ in pairs(myTable) do
        if myTable[i] == myTable[index] then
            myTable[i] = nil
        end
    end
end


-- we append the new clothing defined in the mod's media/lua/shared/Definitions/RasProfessionsClothing.lua to the vanilla clothing list; is called at the end of DoRasProfessions
function RasProfessionsMain.DoRasClothing(prof)
    local newDefs = RasProfessionsClothingDefinitions
    local vanillaDefs = ClothingSelectionDefinitions
    if prof and prof ~= "default" then -- if we work with profession clothing
           local profession = prof:getType()
           if newDefs[profession] then           
                 for _, gender in pairs{"Female", "Male"} do
                          if newDefs[profession][gender] then
                                   for bodyLocation, value in pairs(newDefs[profession][gender]) do 
                                           if value then
                                                  RasProfessionsMain.InitClothingSlot(profession,gender,bodyLocation) -- create clothing slots
                                                  if value.items then  
                                                       for _, clothingItem in pairs(value.items) do
                                                            if not RasProfessionsMain.Contains(vanillaDefs[profession][gender][bodyLocation]["items"], clothingItem) then -- don't duplicate elements!
                                                                  table.insert(vanillaDefs[profession][gender][bodyLocation]["items"], clothingItem)
                                                            end
                                                       end
                                                  end
                                                  if value.remove then -- case we want to remove vanilla clothing
                                                        for _, itemToBeRemoved in pairs(value.remove) do
                                                            RasProfessionsMain.RemoveByValue(vanillaDefs[profession][gender][bodyLocation]["items"], itemToBeRemoved)
                                                        end 
                                                  end
                                                  if value.chance then  -- in case we defined a chance (use with caution! does not always works as intended!) 
                                                      vanillaDefs[profession][gender][bodyLocation]["chance"] = value.chance
                                                  end
                                           end
                                 end
                         end
                 end
                 if newDefs[profession]["RemoveLocation"] then
                          for _,v in pairs(newDefs[profession]["RemoveLocation"]["Female"]) do -- I remove some vanilla body locations for clothing selection which I consider a bit inappropriate
                                RasProfessionsMain.RemoveField(vanillaDefs[profession]["Female"], v)
                          end
                          if vanillaDefs[profession]["Male"] and newDefs[profession]["RemoveLocation"]["Male"] then
                                for _,v in pairs(newDefs[profession]["RemoveLocation"]["Male"]) do
                                       RasProfessionsMain.RemoveField(vanillaDefs[profession]["Male"], v)
                                end
                          end
                 end
          end
    elseif prof == "default" then    -- if we work with default clothing
         if newDefs["default"] then
              for _, gender in pairs{"Female", "Male"} do 
                    if newDefs["default"][gender] then
                       for bodyLocation, value in pairs(newDefs["default"][gender]) do
                            if value then
                                   RasProfessionsMain.InitClothingSlot("default",gender,bodyLocation) -- create clothing slots (but now for default clothing)
                                   if value.items then  
                                        for _, clothingItem in pairs(value.items) do
                                                  if not RasProfessionsMain.Contains(vanillaDefs["default"][gender][bodyLocation]["items"], clothingItem) then -- no double elements!
                                                               table.insert(vanillaDefs["default"][gender][bodyLocation]["items"], clothingItem)
                                                  end
                                        end
                                   end
                                   if value.remove then -- case we want to remove vanilla clothing
                                        for _, itemToBeRemoved in pairs(value.remove) do
                                                    RasProfessionsMain.RemoveByValue(vanillaDefs["default"][gender][bodyLocation]["items"], itemToBeRemoved)
                                        end 
                                   end
                                   if value.chance then  -- in case we defined a chance (use with caution! does not always works as intended!) 
                                          vanillaDefs["default"][gender][bodyLocation]["chance"] = value.chance
                                   end
                            end
                       end
                  end
            end
        end
    end
end 

 
    
    
-- put profession items in player inventory (called in CreatePlayer())
function RasProfessionsMain.addInventory(player)
         local profession = player:getDescriptor():getProfession()
         local playerInventory = player:getInventory()
         if inventory[profession] then
             for index, value in pairs(inventory[profession]) do
                     if getScriptManager():FindItem(value) then
                         playerInventory:AddItems(value, 1)
                     end
             end
         end
end

-- swap the custom traits from DoRasProfessionTraits with their vanilla counterparts (called in CreatePlayer())
function RasProfessionsMain.swapTraits(player)         
         for i,traitPair in pairs(traitsToSwap) do 
              if player:HasTrait(traitPair.swap) then                   
                   if traitPair.swap ~= "rasOutOfShapeProf" then -- outOfShape trait gets special treatment in client folder                     
                       player:getTraits():remove(traitPair.swap)
                       player:getTraits():add(traitPair.with)
                   end
              end
         end                           
end



RasProfessionsMain.ShouldAttachWeapon = false -- this will tell us whether we have a profession which should get a weapon attached on start

-- create the player: add profession items to inventory, attach weapons, swap custom traits with vanilla ones etc; called via lua event OnNewGame
function RasProfessionsMain.CreatePlayer(player, square)
         RasProfessionsMain.addInventory(player) -- add inventory items
         RasProfessionsMain.swapTraits(player) -- swap traits
         
         -- some professions get special treatment regarding their starting equipment
         local profession = player:getDescriptor():getProfession()
                  
         if profession == "policeofficer" or profession == "securityguard" then  -- they should start with their weapons attached; done in client/Hotbar/RasProfessionsAttach.lua
                RasProfessionsMain.ShouldAttachWeapon = true
                
         elseif profession == "rasStudent" then -- put some random items in student's backpack
               local backpack = player:getWornItem("Back")
               if backpack then 
                   if backpack:getFullType() == "Base.Bag_Schoolbag" then -- only if backpack is worn      
                         local junk = { }
                         junk[0] = "Base.Book"
                         junk[1] = "Base.Eraser"  
                         junk[2] = "Base.Pencil"
                         junk[3] = "Base.Paperclip"
                         junk[4] = "Base.Magazine"
                         junk[5] = "Base.Apple"
                         junk[6] = "Radio.CDplayer"
                         junk[7] = "Base.Disc_Retail"
                         junk[8] = "Base.Earbuds"
                  
                         local size = 9
                         local e = 2 + ZombRand(4) -- add between two and five random items
                         for i=1,e do
                             local index = ZombRand(size)
                             local item = InventoryItemFactory.CreateItem(junk[index])
                             backpack:getInventory():addItem(item)
                             if index ~= size - 1 then
                                 junk[index] = junk[size - 1]  -- write last item to current index so we can just remove the last entry of the table and have no issues with indices
                             end
                             table.remove(junk, size - 1)
                             size = size - 1
                        end
                   end                  
              end       
                
         elseif profession == "rasHomeless" then -- homeless starts with garbage bag equipped and low condition clothing
                local garbagebag = InventoryItemFactory.CreateItem("Base.Garbagebag") 
                
                local twine = InventoryItemFactory.CreateItem("Base.Twine")  -- random junk to be added to garbagebag
                local sneakers = InventoryItemFactory.CreateItem("Base.Shoes_TrainerTINT") 
                sneakers:setCondition(ZombRand(3) + 1 )
                sneakers:setDirtyness(ZombRand(30))
                local socks = InventoryItemFactory.CreateItem("Base.Socks_Ankle")
                socks:setCondition(5 + ZombRand(5))
                socks:setDirtyness(70 + ZombRand(31))
                local matches = InventoryItemFactory.CreateItem("Base.Matches")
                local toiletpaper = InventoryItemFactory.CreateItem("Base.ToiletPaper")
                local newspaper =  InventoryItemFactory.CreateItem("Base.Newspaper")
                local toothbrush = InventoryItemFactory.CreateItem("Base.Toothbrush")
                local apple = InventoryItemFactory.CreateItem("Base.Apple")
                apple:setAge(5.5)
                
                local junk = { } 
                junk[0] = twine
                junk[1] = sneakers
                junk[2] = socks
                junk[3] = matches
                junk[4] = toiletpaper
                junk[5] = newspaper
                junk[6] = toothbrush
                junk[7] = apple
                
                local size = 8 
                local e = 2 + ZombRand(3) -- add between two and four  junk items
                for i=1,e do
                    local index = ZombRand(size)
                    garbagebag:getInventory():addItem(junk[index])
                    if index ~= size - 1 then
                        junk[index] = junk[size - 1] 
                    end
                    table.remove(junk, size - 1)
                    size = size - 1
                end
                
                player:getInventory():addItem(garbagebag)
                player:setSecondaryHandItem(garbagebag)
                
                local allLocations = BodyLocations.getGroup("Human"):getAllLocations() -- lower condition of worn clothes and make them dirty
                for i=0, allLocations:size()-1 do
                    local bodyLocation = allLocations:get(i):getId()
                    local item = player:getWornItem(bodyLocation)
                    if item then
                       local n = item:getCondition()
                       item:setCondition(n - math.floor(n/2) + ZombRand(math.floor(n/2) + 1) )
                       item:setDirtyness(ZombRand(30))
                    end
                end
                
         elseif profession == "rasOfficeEmployee" then -- office employee starts with briefcase equipped
                local briefcase = InventoryItemFactory.CreateItem("Base.Briefcase") 
                
                local junk = { } -- add some random junk to the briefcase
                junk[0] = "Base.Notebook"
                junk[1] = "Base.Pen"
                junk[2] = "Base.Newspaper"
                junk[3] = "Base.Wallet4"
                junk[4] = "Base.Money"
                junk[5] = "Base.PaperclipBox"
                junk[6] = "Base.Cube"
                junk[7] = "Base.CheeseSandwich"
               
                local size = 8
                local e = 2 + ZombRand(3) -- add between two and four random items
                for i=1,e do
                    local index = ZombRand(size)
                    local item = InventoryItemFactory.CreateItem(junk[index])
                    briefcase:getInventory():addItem(item)
                    if index ~= size - 1 then
                        junk[index] = junk[size - 1]
                    end
                    table.remove(junk, size - 1)
                    size = size - 1
                end
                
                player:getInventory():addItem(briefcase) -- put briefcase to inventory
                player:setSecondaryHandItem(briefcase) -- equip briefcase
                
         elseif profession == "rasMailCarrier" then -- put some random junk in mail carrier's satchel
               local satchel = player:getWornItem("Back")
               if satchel then
                   if satchel:getFullType() == "Base.Bag_Satchel" then -- only if satchel is worn      
                         local junk = { }
                         junk[0] = "Base.SheetPaper2"
                         junk[1] = "Base.SheetPaper2"
                         junk[2] = "Base.Pen"
                         junk[3] = "Base.Paperclip"
                         junk[4] = "Base.Paperclip"
                         junk[5] = "Base.Magazine"
                         junk[6] = "Base.FishingMag2"
                  
                         local size = 7
                         local e = 2 + ZombRand(2) -- add two or three random items
                         for i=1,e do
                             local index = ZombRand(size)
                             local item = InventoryItemFactory.CreateItem(junk[index])
                             satchel:getInventory():addItem(item)
                             if index ~= size - 1 then
                                 junk[index] = junk[size - 1]
                             end
                             table.remove(junk, size - 1)
                             size = size - 1
                        end
                   end                  
              end 
       end                 
end
    
 
   
-- in the next two functions we append DoRasTraits() and DoRasProfessions() to their vanilla counterparts so that players are able to choose the professions when they rejoin an already existing 
-- world after player death; vanilla code is still executed and not overwritten

local vanilla_DoTraits = BaseGameCharacterDetails.DoTraits
function BaseGameCharacterDetails.DoTraits(...)
         vanilla_DoTraits(...) -- execute vanilla code
         RasProfessionsMain.DoRasTraits()
end         

local vanilla_DoProfessions = BaseGameCharacterDetails.DoProfessions
function BaseGameCharacterDetails.DoProfessions(...)
         vanilla_DoProfessions(...) -- execute vanilla code
         RasProfessionsMain.DoRasProfessions()
end    
    
    
-- execute our new functions via lua events:

Events.OnGameBoot.Add(RasProfessionsMain.DoRasTraits)
Events.OnGameBoot.Add(RasProfessionsMain.DoRasProfessions)

Events.OnNewGame.Add(RasProfessionsMain.CreatePlayer)








