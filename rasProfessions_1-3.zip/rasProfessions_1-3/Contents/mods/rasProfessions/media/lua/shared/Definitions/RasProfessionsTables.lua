-- contains several tables used by this mod
--
--
-- by razab


RasProfessionsTables = { }

-- contains hair colors for younger persons; no grey-ish colors (only applied to student and gang member)
RasProfessionsTables.YoungColors = { }
RasProfessionsTables.YoungColors[1] = { r = 0.8313725590705872, g = 0.6705882549285889, b = 0.2705882489681244 }
RasProfessionsTables.YoungColors[2] = { r = 0.6627451181411743, g = 0.5215686559677124, b = 0.3176470696926117 }
RasProfessionsTables.YoungColors[3] = { r = 0.6235294342041016, g = 0.42352941632270813, b = 0.16862745583057404 }
RasProfessionsTables.YoungColors[4] = { r = 0.6117647290229797, g = 0.5098039507865906, b = 0.33725491166114807 }
RasProfessionsTables.YoungColors[5] = { r = 0.5960784554481506, g = 0.43921568989753723, b = 0.2980392277240753 }
RasProfessionsTables.YoungColors[6] = { r = 0.572549045085907, g = 0.4745098054409027, b = 0.3490196168422699 }
RasProfessionsTables.YoungColors[7] = { r = 0.43529412150382996, g = 0.34117648005485535, b = 0.23529411852359772 }
RasProfessionsTables.YoungColors[8] = { r = 0.33725491166114807, g = 0.26274511218070984, b = 0.1764705926179886 }
RasProfessionsTables.YoungColors[9] = { r = 0.3450980484485626, g = 0.2078431397676468, b = 0.13333334028720856 }
RasProfessionsTables.YoungColors[10] = { r = 0.21960784494876862, g = 0.16078431904315948, b = 0.10588235408067703 }
RasProfessionsTables.YoungColors[11] = { r = 0.10588235408067703, g = 0.09019608050584793, b = 0.08627451211214066 }
RasProfessionsTables.YoungColors[12] = { r = 0.7450980544090271, g = 0.5215686559677124, b = 0.40392157435417175 }
RasProfessionsTables.YoungColors[13] = { r = 0.6509804129600525, g = 0.364705890417099, b = 0.24705882370471954 }
RasProfessionsTables.YoungColors[14] = { r = 0.5843137502670288, g = 0.250980406999588, b = 0.250980406999588 }
RasProfessionsTables.YoungColors[15] = {	r = 0.5254902243614197, g = 0.25882354378700256, b = 0.1882352977991104 }


-- contains hair colors for older persons; only grey-ish colors (only applied to retired profession)
RasProfessionsTables.OldColors = { }
RasProfessionsTables.OldColors[1] = { r = 0.48627451062202454, g = 0.47058823704719543,	b = 0.43921568989753723 }
RasProfessionsTables.OldColors[2] = { r = 0.6509804129600525, g = 0.6196078658103943, b = 0.501960813999176 }
RasProfessionsTables.OldColors[3] = { r = 0.7372549176216125, g = 0.6941176652908325, b = 0.615686297416687 }
RasProfessionsTables.OldColors[4] = { r = 0.6509804129600525, g = 0.6431372761726379, b = 0.6235294342041016 }




RasProfessionsTables.AvailableHairStyles = { } -- this is table is populated on game boot, see lua/shared/RasProfessionsMakeHairTable.lua
RasProfessionsTables.AvailableHairStyles.Male = { }
RasProfessionsTables.AvailableHairStyles.Female = { }



-- store all the vanilla hair styles (we have to ensure that AvailableHairStyles list will contain only vanilla hairs; modded hair may cause bugs)
RasProfessionsTables.VanillaHair = { }

RasProfessionsTables.VanillaHair.Male = { }
RasProfessionsTables["VanillaHair"]["Male"]["Bald"] = true
RasProfessionsTables["VanillaHair"]["Male"]["Baldspot"] = true
RasProfessionsTables["VanillaHair"]["Male"]["Braids"] = true
RasProfessionsTables["VanillaHair"]["Male"]["Buffont"] = true
RasProfessionsTables["VanillaHair"]["Male"]["Fresh"] = true
RasProfessionsTables["VanillaHair"]["Male"]["CentreParting"] = true
RasProfessionsTables["VanillaHair"]["Male"]["Cornrows"] = true
RasProfessionsTables["VanillaHair"]["Male"]["CrewCut"] = true
RasProfessionsTables["VanillaHair"]["Male"]["Donny"] = true
RasProfessionsTables["VanillaHair"]["Male"]["Fabian"] = true
RasProfessionsTables["VanillaHair"]["Male"]["FabianCurly"] = true
RasProfessionsTables["VanillaHair"]["Male"]["FlatTop"] = true
RasProfessionsTables["VanillaHair"]["Male"]["GreasedBack"] = true
RasProfessionsTables["VanillaHair"]["Male"]["Grungey"] = true
RasProfessionsTables["VanillaHair"]["Male"]["GrungeyBehindEars"] = true
RasProfessionsTables["VanillaHair"]["Male"]["LeftParting"] = true
RasProfessionsTables["VanillaHair"]["Male"]["LongBraids"] = true
RasProfessionsTables["VanillaHair"]["Male"]["CentrePartingLong"] = true
RasProfessionsTables["VanillaHair"]["Male"]["LongBraids02"] = true
RasProfessionsTables["VanillaHair"]["Male"]["Messy"] = true
RasProfessionsTables["VanillaHair"]["Male"]["MessyCurly"] = true
RasProfessionsTables["VanillaHair"]["Male"]["MohawkFan"] = true
RasProfessionsTables["VanillaHair"]["Male"]["MohawkFlat"] = true
RasProfessionsTables["VanillaHair"]["Male"]["MohawkShort"] = true
RasProfessionsTables["VanillaHair"]["Male"]["MohawkSpike"] = true
RasProfessionsTables["VanillaHair"]["Male"]["Mullet"] = true
RasProfessionsTables["VanillaHair"]["Male"]["MulletCurly"] = true
RasProfessionsTables["VanillaHair"]["Male"]["Picard"] = true
RasProfessionsTables["VanillaHair"]["Male"]["PonyTail"] = true
RasProfessionsTables["VanillaHair"]["Male"]["PonyTailBraids"] = true
RasProfessionsTables["VanillaHair"]["Male"]["Recede"] = true
RasProfessionsTables["VanillaHair"]["Male"]["RightParting"] = true
RasProfessionsTables["VanillaHair"]["Male"]["Short"] = true
RasProfessionsTables["VanillaHair"]["Male"]["ShortHatCurly"] = true
RasProfessionsTables["VanillaHair"]["Male"]["ShortAfroCurly"] = true
RasProfessionsTables["VanillaHair"]["Male"]["Spike"] = true
RasProfessionsTables["VanillaHair"]["Male"]["LibertySpikes"] = true
RasProfessionsTables["VanillaHair"]["Male"]["Metal"] = true

RasProfessionsTables.VanillaHair.Female = { }
RasProfessionsTables["VanillaHair"]["Female"]["Bald"] = true
RasProfessionsTables["VanillaHair"]["Female"]["Bob"] = true
RasProfessionsTables["VanillaHair"]["Female"]["BobCurly"] = true
RasProfessionsTables["VanillaHair"]["Female"]["Braids"] = true
RasProfessionsTables["VanillaHair"]["Female"]["Buffont"] = true
RasProfessionsTables["VanillaHair"]["Female"]["Bun"] = true
RasProfessionsTables["VanillaHair"]["Female"]["BunCurly"] = true
RasProfessionsTables["VanillaHair"]["Female"]["Fresh"] = true
RasProfessionsTables["VanillaHair"]["Female"]["CentreParting"] = true
RasProfessionsTables["VanillaHair"]["Female"]["Cornrows"] = true
RasProfessionsTables["VanillaHair"]["Female"]["Demi"] = true
RasProfessionsTables["VanillaHair"]["Female"]["FlatTop"] = true
RasProfessionsTables["VanillaHair"]["Female"]["GreasedBack"] = true
RasProfessionsTables["VanillaHair"]["Female"]["Grungey"] = true
RasProfessionsTables["VanillaHair"]["Female"]["GrungeyBehindEars"] = true
RasProfessionsTables["VanillaHair"]["Female"]["Grungey02"] = true
RasProfessionsTables["VanillaHair"]["Female"]["GrungeyParted"] = true
RasProfessionsTables["VanillaHair"]["Female"]["LeftParting"] = true
RasProfessionsTables["VanillaHair"]["Female"]["Long"] = true
RasProfessionsTables["VanillaHair"]["Female"]["Longcurly"] = true
RasProfessionsTables["VanillaHair"]["Female"]["Long2"] = true
RasProfessionsTables["VanillaHair"]["Female"]["Long2curly"] = true
RasProfessionsTables["VanillaHair"]["Female"]["LongBraids"] = true
RasProfessionsTables["VanillaHair"]["Female"]["CentrePartingLong"] = true
RasProfessionsTables["VanillaHair"]["Female"]["LongBraids02"] = true
RasProfessionsTables["VanillaHair"]["Female"]["MohawkFan"] = true
RasProfessionsTables["VanillaHair"]["Female"]["MohawkFlat"] = true
RasProfessionsTables["VanillaHair"]["Female"]["MohawkShort"] = true
RasProfessionsTables["VanillaHair"]["Female"]["MohawkSpike"] = true
RasProfessionsTables["VanillaHair"]["Female"]["Kate"] = true
RasProfessionsTables["VanillaHair"]["Female"]["KateCurly"] = true
RasProfessionsTables["VanillaHair"]["Female"]["OverEye"] = true
RasProfessionsTables["VanillaHair"]["Female"]["OverEyeCurly"] = true
RasProfessionsTables["VanillaHair"]["Female"]["OverLeftEye"] = true
RasProfessionsTables["VanillaHair"]["Female"]["PonyTail"] = true
RasProfessionsTables["VanillaHair"]["Female"]["PonyTailBraids"] = true
RasProfessionsTables["VanillaHair"]["Female"]["Back"] = true
RasProfessionsTables["VanillaHair"]["Female"]["Rachel"] = true
RasProfessionsTables["VanillaHair"]["Female"]["RachelCurly"] = true
RasProfessionsTables["VanillaHair"]["Female"]["RightParting"] = true
RasProfessionsTables["VanillaHair"]["Female"]["ShortCurly"] = true
RasProfessionsTables["VanillaHair"]["Female"]["Spike"] = true
RasProfessionsTables["VanillaHair"]["Female"]["LibertySpikes"] = true
RasProfessionsTables["VanillaHair"]["Female"]["TopCurls"] = true





-- contains hair styles which a profession shouldn't get randomly assigned during character creation; can still be choosen manually by player if desired
RasProfessionsTables.ExcludedHairStyles = { }

RasProfessionsTables.ExcludedHairStyles.Male = { 
   unemployed = {  },
   fireofficer = { "LibertySpikes", "MohawkSpike", "MohawkFan", "MohawkFlat", "MohawkShort",
                   "Fabian", "FabianCurly", "LongBraids", "LongBraids02", "Metal" },
   policeofficer = { "LibertySpikes", "MohawkSpike", "MohawkFan", "MohawkFlat", "MohawkShort", 
                     "Braids", "Fabian", "FabianCurly", "LongBraids", "LongBraids02", "Mullet", "MulletCurly", "CentrePartingLong", "Metal" },
   parkranger = { "LibertySpikes", "MohawkSpike", "MohawkFan", "MohawkFlat", "MohawkShort"},
   constructionworker = { "LibertySpikes", "MohawkSpike", "MohawkFan"},
   securityguard = { "LibertySpikes", "MohawkSpike", "MohawkFan", "MohawkFlat",
                     "Fabian", "FabianCurly", "LongBraids", "LongBraids02", "Metal"},
   carpenter = { "LibertySpikes", "MohawkSpike", "MohawkFan", "MohawkFlat", "MohawkShort"},
   burglar = { "LibertySpikes", "MohawkSpike", "MohawkFan"},
   chef = { "LibertySpikes", "MohawkSpike", "MohawkFan", "MohawkFlat", "MohawkShort"},
   repairman = { "LibertySpikes", "MohawkSpike", "MohawkFan", "MohawkFlat", "MohawkShort"},
   farmer = { "LibertySpikes", "MohawkSpike", "MohawkFan", "MohawkFlat", "MohawkShort"},
   fisherman = { "LibertySpikes", "MohawkSpike", "MohawkFan", "MohawkFlat", "MohawkShort"},
   doctor = { "LibertySpikes", "MohawkSpike", "MohawkFan", "MohawkFlat", "MohawkShort",
              "Fabian", "FabianCurly", "LongBraids", "LongBraids02", "Mullet", "MulletCurly", "Metal" },
   veteran = { "LibertySpikes", "MohawkSpike", "MohawkFan"},
   nurse = { "LibertySpikes", "MohawkSpike", "MohawkFan", "MohawkFlat", "MohawkShort"},
   lumberjack = { "LibertySpikes", "MohawkSpike", "MohawkFan"},
   fitnessInstructor = { "LibertySpikes", "MohawkSpike", "MohawkFan"},
   burgerflipper = { "LibertySpikes", "MohawkSpike", "MohawkFan"},
   electrician = { "LibertySpikes", "MohawkSpike", "MohawkFan", "MohawkFlat", "MohawkShort"},
   engineer = { "LibertySpikes", "MohawkSpike", "MohawkFan", "MohawkFlat", "MohawkShort",
                 "Fabian", "FabianCurly", "LongBraids", "LongBraids02", "Metal"},
   metalworker = { "LibertySpikes", "MohawkSpike", "MohawkFan"},
   mechanics = { "LibertySpikes", "MohawkSpike", "MohawkFan"},
   rasTeacher = { "LibertySpikes", "MohawkSpike", "MohawkFan", "MohawkFlat", "MohawkShort",},
   rasBotanist = { "LibertySpikes", "MohawkSpike", "MohawkFan", "MohawkFlat", "MohawkShort"},
   rasWasteCollector = { "LibertySpikes", "MohawkSpike", "MohawkFan"},
   rasStudent = { "Baldspot", "Picard", "Recede" },
   rasDeliveryDriver = { },
   rasLibrarian = { "LibertySpikes", "MohawkSpike", "MohawkFan", "MohawkFlat", "MohawkShort"},
   rasPriest = { "LibertySpikes", "MohawkSpike", "MohawkFan", "MohawkFlat", "MohawkShort"},
   rasTailor = { "LibertySpikes", "MohawkSpike", "MohawkFan", "MohawkFlat", "MohawkShort"},
   rasITProf = { },
   rasArchitect = { "LibertySpikes", "MohawkSpike", "MohawkFan", "MohawkFlat", "MohawkShort",
                    "Fabian", "FabianCurly", "LongBraids", "LongBraids02", "Metal"},
   rasVeterinarian = { "LibertySpikes", "MohawkSpike", "MohawkFan", "MohawkFlat", "MohawkShort"},
   rasOfficeEmployee = { "LibertySpikes", "MohawkSpike", "MohawkFan", "MohawkFlat", "MohawkShort",
                         "Fabian", "FabianCurly", "LongBraids", "LongBraids02", "Metal"},
   rasHomeless = { "LibertySpikes", "MohawkSpike", "MohawkFan"},
   rasGangMember = { },
   rasMailCarrier = { "LibertySpikes", "MohawkSpike", "MohawkFan", "MohawkFlat", "MohawkShort"},
   rasPharmacist = { "LibertySpikes", "MohawkSpike", "MohawkFan", "MohawkFlat", "MohawkShort",
                     "Fabian", "FabianCurly", "LongBraids", "LongBraids02", "Mullet", "MulletCurly", "Metal"}, 
   rasRetired = { "Braids", "Cornrows", "Donny", "Fabian", "FabianCurly", "CrewCut", "Fresh", "LongBraids", "Grungey", "GrungeyBehindEars", "LongBraids02", "MohawkFan", "MohawkFlat", "MohawkShort", "MohawkSpike",
                  "PonyTail", "PonyTailBraids", "ShortAfroCurly", "Spike", "LibertySpikes", "Metal" },
}




RasProfessionsTables.ExcludedHairStyles.Female = { 
   unemployed = {  },
   fireofficer = { "LibertySpikes", "MohawkSpike", "MohawkFan", "MohawkFlat", "MohawkShort" },
   policeofficer = { "LibertySpikes", "MohawkSpike", "MohawkFan", "MohawkFlat", "MohawkShort" },
   parkranger = { "LibertySpikes", "MohawkSpike", "MohawkFan", "MohawkFlat", "MohawkShort"},
   constructionworker = { "LibertySpikes", "MohawkSpike", "MohawkFan"},
   securityguard = { "LibertySpikes", "MohawkSpike", "MohawkFan", "MohawkFlat"},
   carpenter = { "LibertySpikes", "MohawkSpike", "MohawkFan", "MohawkFlat", "MohawkShort"},
   burglar = { "LibertySpikes", "MohawkSpike", "MohawkFan"},
   chef = { "LibertySpikes", "MohawkSpike", "MohawkFan", "MohawkFlat", "MohawkShort"},
   repairman = { "LibertySpikes", "MohawkSpike", "MohawkFan", "MohawkFlat", "MohawkShort"},
   farmer = { "LibertySpikes", "MohawkSpike", "MohawkFan", "MohawkFlat", "MohawkShort"},
   fisherman = { "LibertySpikes", "MohawkSpike", "MohawkFan", "MohawkFlat", "MohawkShort"},
   doctor = { "LibertySpikes", "MohawkSpike", "MohawkFan", "MohawkFlat", "MohawkShort"},
   veteran = { "LibertySpikes", "MohawkSpike", "MohawkFan"},
   nurse = { "LibertySpikes", "MohawkSpike", "MohawkFan", "MohawkFlat", "MohawkShort"},
   lumberjack = { "LibertySpikes", "MohawkSpike", "MohawkFan"},
   fitnessInstructor = { "LibertySpikes", "MohawkSpike", "MohawkFan"},
   burgerflipper = { "LibertySpikes", "MohawkSpike", "MohawkFan"},
   electrician = { "LibertySpikes", "MohawkSpike", "MohawkFan", "MohawkFlat", "MohawkShort"},
   engineer = { "LibertySpikes", "MohawkSpike", "MohawkFan", "MohawkFlat", "MohawkShort"},
   metalworker = { "LibertySpikes", "MohawkSpike", "MohawkFan"},
   mechanics = { "LibertySpikes", "MohawkSpike", "MohawkFan"},
   rasTeacher = { "LibertySpikes", "MohawkSpike", "MohawkFan", "MohawkFlat", "MohawkShort"},
   rasBotanist = { "LibertySpikes", "MohawkSpike", "MohawkFan", "MohawkFlat", "MohawkShort"},
   rasWasteCollector = { "LibertySpikes", "MohawkSpike", "MohawkFan"},
   rasStudent = { },
   rasDeliveryDriver = { },
   rasLibrarian = { "LibertySpikes", "MohawkSpike", "MohawkFan", "MohawkFlat", "MohawkShort"},
   rasPriest = { "LibertySpikes", "MohawkSpike", "MohawkFan", "MohawkFlat", "MohawkShort"},
   rasTailor = { "LibertySpikes", "MohawkSpike", "MohawkFan", "MohawkFlat", "MohawkShort"},
   rasITProf = { },
   rasArchitect = { "LibertySpikes", "MohawkSpike", "MohawkFan", "MohawkFlat", "MohawkShort"},
   rasVeterinarian = { "LibertySpikes", "MohawkSpike", "MohawkFan", "MohawkFlat", "MohawkShort"},
   rasOfficeEmployee = { "LibertySpikes", "MohawkSpike", "MohawkFan", "MohawkFlat", "MohawkShort"},
   rasHomeless = { "LibertySpikes", "MohawkSpike", "MohawkFan"},
   rasGangMember = { },
   rasMailCarrier = { "LibertySpikes", "MohawkSpike", "MohawkFan", "MohawkFlat", "MohawkShort"},
   rasPharmacist = { "LibertySpikes", "MohawkSpike", "MohawkFan", "MohawkFlat", "MohawkShort"},
   rasRetired = { "Bald", "Fresh", "Cornrows", "Demi", "FlatTop", "MohawkFan", "MohawkFlat", "MohawkShort", "MohawkSpike", "Spike", "LibertySpikes"},
}







