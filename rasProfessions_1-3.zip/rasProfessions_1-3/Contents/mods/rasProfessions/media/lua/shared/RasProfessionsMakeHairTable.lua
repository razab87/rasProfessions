-- we populate the list RasProfessionsTables.AvailableHairStyles; this contains the hairstyles which the game may randomly assign to a profession during character customisation; only called once OnGameBoot
--
--
-- by razab



RasProfessionsMakeHairTable = { }



-- check whether table contains value
local function contains(aTable, value)
      for _,v in pairs(aTable) do
           if v == value then
               return true
           end 
      end
      return false
end


function RasProfessionsMakeHairTable.MakeTable ()

     local resultTableMale = RasProfessionsTables.AvailableHairStyles.Male
     local resultTableFemale = RasProfessionsTables.AvailableHairStyles.Female

     local excludedStylesMale = RasProfessionsTables.ExcludedHairStyles.Male
     local excludedStylesFemale = RasProfessionsTables.ExcludedHairStyles.Female
     
     local professions = ProfessionFactory.getProfessions()
     for i=1,professions:size() do
           local profId = professions:get(i-1):getType()

           -- populate table for male
           if excludedStylesMale[profId] then -- only for professions from vanilla and from this mod
                resultTableMale[profId] = { }
                local hairStylesMale = getAllHairStyles(false) -- note: false is for male
                for i=1,hairStylesMale:size() do
                      local style = hairStylesMale:get(i-1)
                      if RasProfessionsTables["VanillaHair"]["Male"][style] then -- only for vanilla hair style (modded hair styles will not automatically get assigned but can still be choosen manually)                     
                            if not contains(excludedStylesMale[profId], style) then
                                 table.insert(resultTableMale[profId],style)
                            end
                      end
                end
           end 
           
           -- populate table for female
           if excludedStylesFemale[profId] then -- only for professions from vanilla and this mod
                resultTableFemale[profId] = { }           
                local hairStylesFemale = getAllHairStyles(true) -- note: true is for female
                for i=1,hairStylesFemale:size() do
                      local style = hairStylesFemale:get(i-1)
                      if RasProfessionsTables["VanillaHair"]["Female"][style] then                   
                          if not contains(excludedStylesFemale[profId], style) then
                              table.insert(resultTableFemale[profId],style)
                          end
                      end
                end 
           end
     end 
end




Events.OnGameBoot.Add(RasProfessionsMakeHairTable.MakeTable)






