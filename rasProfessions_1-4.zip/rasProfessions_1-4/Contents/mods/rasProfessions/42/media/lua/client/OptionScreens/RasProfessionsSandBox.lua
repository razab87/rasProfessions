-- re-create profession list in case player changes a sandbox option
--
--
-- by razab


local vanilla_onOptionMouseDown = SandboxOptionsScreen.onOptionMouseDown
function SandboxOptionsScreen:onOptionMouseDown(button, x, y, ...)

    vanilla_onOptionMouseDown(self, button, x, y, ...)

    if button.internal == "PLAY" then
        ProfessionFactory.Reset() -- reset all professions
        BaseGameCharacterDetails.DoProfessions() -- re-create all professions
        MainScreen.instance.charCreationProfession.listboxProf:clear() -- clear profession list in prof selection menu
        MainScreen.instance.charCreationProfession:populateProfessionList(MainScreen.instance.charCreationProfession.listboxProf) -- repopulate the list
    end
end



