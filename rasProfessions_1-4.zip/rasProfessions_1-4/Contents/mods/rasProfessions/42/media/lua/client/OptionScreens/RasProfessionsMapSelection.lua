-- store selected starting city
--
--
-- by razab


local rasSharedData = require("RasProfessionsSharedData")



local vanilla_clickNext = MapSpawnSelect.clickNext
function MapSpawnSelect:clickNext(...)
       
    vanilla_clickNext(self,...) -- execute vanilla code
       
    if self.selectedRegion.name == "Muldraugh, KY" then
        rasSharedData.StartingCity = "Muldraugh"
    elseif self.selectedRegion.name == "West Point, KY" then
        rasSharedData.StartingCity = "WestPoint"
    elseif self.selectedRegion.name == "Riverside, KY" then
        rasSharedData.StartingCity = "Riverside"
    elseif self.selectedRegion.name == "Rosewood, KY" then
        rasSharedData.StartingCity = "Rosewood"
    elseif self.selectedRegion.name == "Echo Creek, KY" then
        rasSharedData.StartingCity = "EchoCreek"
    end
end





