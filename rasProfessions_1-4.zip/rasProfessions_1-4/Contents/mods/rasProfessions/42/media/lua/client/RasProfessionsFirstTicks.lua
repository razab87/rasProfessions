-- this code does the following things: 
--    - make player spawn on correct location; is done manually since it will later result in better multiplayer compatibility
--    - remove zombies from spawn house, remove house alarm from spawn house (necessary since spawns are done manually)
--    - turn lights on in spawn house (better because of the new B42 lighting system, avoid pitch black starts)
--    - give keys for starter house
--    - remove OutOfShape profession trait from "retired" (do this manually since vanilla game has strange behavior for that specific trait)
--
--
-- by razab


local MAX_TICKS = 100


local rasSharedData = require("RasProfessionsSharedData")

-- give player starter house keys
local function giveHouseKeys(tick)

    if tick >= MAX_TICKS then
        Events.OnTick.Remove(giveHouseKeys) -- remove from events (in case something strange happened...)
    end

    local player = getPlayer()
    local square = player:getSquare()
    if square then        
        local keyring =  player:getInventory():getItemFromType("Base.KeyRing")
        if keyring then 
            keyring:getInventory():RemoveAll("Base.Key1")
            local building = square:getBuilding() 
            if building and building:isResidential() and player:getDescriptor():getProfession() ~= "rasHomeless" then -- no house keys for homeless; no house keys for non-residential buildings
                key = instanceItem("Base.Key1")
                key:setKeyId(building:getDef():getKeyId())
		        ItemPickerJava.keyNamerBuilding(key, square)
                keyring:getInventory():addItem(key)
            end
        end
        Events.OnTick.Remove(giveHouseKeys) -- remove from events
    end
end


-- remove OutOfShape trait in case player has selected "retired" profession
local function fixOutOfShape(tick)

    local player = getPlayer()    
    if player:HasTrait("rasOutOfShapeProf") then
        player:getTraits():remove("rasOutOfShapeProf")
    end
    Events.OnTick.Remove(fixOutOfShape)
end

-- turn on lights in start room
local function turnLightsOn(tick)

    if tick >= MAX_TICKS then
        Events.OnTick.Remove(turnLightsOn) -- remove from events (in case of strange errors...)
    end

    local player = getPlayer()
    local square = player:getSquare()
    if square then 
        local room = square:getRoom()
        if room then
            local lights = room:getLightSwitches()
            for i=0, lights:size() - 1 do
                lights:get(i):setActivated(true) -- turn lights on
                lights:get(i):switchLight(true)
            end                
        end 
        Events.OnTick.Remove(turnLightsOn) -- remove from events
    end
end

-- remove zombies from starting area
local function removeZombies(tick)

    if tick >= MAX_TICKS then
        Events.OnTick.Remove(removeZombies) -- remove from events (in case of strange errors...)
    end 
         
    local player = getPlayer()
    local square = player:getSquare()
    if square then

        local x = square:getX()
        local y = square:getY()
        local maxValue = 15
        local minX = x - maxValue
        local maxX = x + maxValue
        local minY = y - maxValue
        local maxY = y + maxValue

        local loaded_all = true -- first check whether all squares around the player are already loaded

        local building = square:getBuilding()
        local rooms = nil
        if building then
            rooms = building:getDef():getRooms()
            for i=1,rooms:size() do
                local room = rooms:get(i-1) 
                local squares = room:getIsoRoom():getSquares()
                if squares:size() == 0 then
                     loaded_all = false
                     break;
                end
            end
        end

        if loaded_all then           
            for i=minX,maxX do
                for j=minY,maxY do
                    local sq = getSquare(i,j,0)
                    if not sq then
                        loaded_all = false 
                        break;
                    end
                end
            end     
        end

        if loaded_all or tick >= MAX_TICKS then -- when all squares are loaded, remove the zombies (or waited too long, >= 100 ticks)

            -- remove zombies from starter house  
            if rooms then      
                for i=1,rooms:size() do
                    local room = rooms:get(i-1)
                    local squares = room:getIsoRoom():getSquares()
                    for j=1,squares:size() do
                        local sq = squares:get(j-1)
                        local zombie = sq:getZombie()
                        while zombie do  
                            print("rasProfessions_Info: zombie in starter house removed")
                            zombie:removeFromWorld() 
                            zombie:removeFromSquare()                   
                            zombie = sq:getZombie()
                        end  
                    end
                end
            end
            
            -- remove all zombies in a 30x30 grid area centered around player
            local objectList = getCell():getObjectList()
            for i=objectList:size(),1,-1 do -- note: list gets smaller when removing zeds, therefore start with i=size
                local obj = objectList:get(i-1)
                if instanceof(obj, "IsoZombie") then
                    local sq = obj:getSquare()
                    if sq and not sq:getBuilding() then
                        local sqX = sq:getX()
                        local sqY = sq:getY()
                        if sqX >= minX and sqX <= maxX and sqY >= minY and sqY <= maxY then -- only remove when near player
		                    obj:removeFromWorld()
		                    obj:removeFromSquare()
                            print("rasProfessions_Info: zombie near starter house removed")
                        end
                    end
	            end
            end                       
            Events.OnTick.Remove(removeZombies) -- remove from events
        end
    end  
end

-- teleport to start location; remove house alarm from starter house
local function teleportToStartPoint(player)

    local profession = player:getDescriptor():getProfession()

    local city = rasSharedData.StartingCity
    if rasSharedData["Spawns"][city] and rasSharedData["Spawns"][city][profession] then
        local spawns = rasSharedData["Spawns"][city][profession]
        local n = ZombRand(#spawns) + 1
        local point = spawns[n]
        local x = nil
        local y = nil
        local z = 0
        if point["posX"] and point["posY"] then
            if point["worldX"] then
                x = (point["worldX"]*300) + point["posX"] -- old coordinate format
                if point["worldY"] then
                    y = (point["worldY"]*300) + point["posY"]
                else
                    print("rasProfessions_WARN: Spawnpoint for ", profession, " in ", city, " not correctly defined!")
                end   
            else
               x = point["posX"]  
               y = point["posY"]
            end
            if point["posZ"] then
                z = point["posZ"]
            end
        else
            print("rasProfessions_WARN: Spawnpoint for ", profession, " in ", city, " not correctly defined!")
        end
 
        if x and y then
            local building = getWorld():getMetaGrid():getBuildingAt(x, y)
            if building then
                building:setAlarmed(false) -- no alarm in starter house
            end
            player:teleportTo(x, y, z) -- teleport player to spawn location
        end
    end
end

-- execute everything OnNewGame
local function mainFunction(player)

    if SandboxVars.RasProfessions.ModdedSpawnPoints then
    
        teleportToStartPoint(player)

        Events.OnTick.Add(giveHouseKeys)
        Events.OnTick.Add(fixOutOfShape)   
        Events.OnTick.Add(turnLightsOn)
        Events.OnTick.Add(removeZombies)
    end
end

Events.OnNewGame.Add(mainFunction)






