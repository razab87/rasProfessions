



-- { worldX = 35, worldY = 34, posX = 251, posY = 221 }, -- trailer (B42)



--local function teleportToStartPos(player)

    --local player = getPlayer()
--    local x = 35*300+251
--    local y = 34*300+221
--    player:teleportTo(x, y, 0)
    --Events.OnTick.Remove(teleportToStartPos) -- do this only on the first tick when new game starts
--end


--Events.OnTick.Add(teleportToStartPos)
--Events.OnNewGame.Add(teleportToStartPos)
