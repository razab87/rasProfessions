-- this code does the following things: 
--    - make player spawn on correct location (is done manually since it will later result in better multiplayer compatibility)
--    - remove zombies from spawn house, remove house alarm from spawn house (necessary since spawns are done manually)
--    - turn lights on in spawn house (better because of the new B42 lighting system, avoid pitch black starts)
--    - give keys for starter house
--    - remove OutOfShape profession trait from "retired" (do this manually since vanilla game has strange behavior for that specific trait)
--
--
-- by razab




local rasSharedData = require("RasProfessionsSharedData")


local startX  -- spawn location
local startY


local squaresToCheck = {} -- some data used for the zombie removal
local remainingSquares = 0
local removalQueue = {}
local queueLen = 0


-- give player starter house keys
local function giveHouseKeys(tick)

    local player = getPlayer()
    local square = player:getSquare()
    if square then        
        local keyring =  player:getInventory():getItemFromType("Base.KeyRing")
        if keyring then 
            keyring:getInventory():RemoveAll("Base.Key1")
            local building = square:getBuilding()
            local buildingDef = building:getDef() 
            if building and buildingDef and building:isResidential() and not buildingDef:isShop() and player:getDescriptor():getProfession() ~= "rasHomeless" then
                key = instanceItem("Base.Key1")
                key:setKeyId(buildingDef:getKeyId())
		        ItemPickerJava.keyNamerBuilding(key, square)
                keyring:getInventory():addItem(key)
            end
        end
        Events.OnTick.Remove(giveHouseKeys) -- remove from events
    end
end


-- remove OutOfShape trait in case player has selected "retired" profession
local function fixOutOfShape(tick)

    local player = getPlayer()    
    if player:HasTrait("rasOutOfShapeProf") then
        player:getTraits():remove("rasOutOfShapeProf")
    end
    Events.OnTick.Remove(fixOutOfShape)
end


-- turn on lights in start room
local function turnLightsOn(tick)

    local player = getPlayer()
    local square = player:getSquare()
    if square then 
        local room = square:getRoom()
        if room then
            local lights = room:getLightSwitches()
            for i=0, lights:size() - 1 do
                lights:get(i):setActivated(true) -- turn lights on
                lights:get(i):switchLight(true)
            end                
        end 
        Events.OnTick.Remove(turnLightsOn) -- remove from events
    end
end


-- remove the zombies
local startTickRemove = nil
local function removeZombies(tick)

    if not startTickRemove then
        startTickRemove = tick -- in any case, we cancel after 100 ticks so remember start tick
    end

    local removalTime = tick + 5
    if remainingSquares > 0 then
        removalQueue[removalTime] = {} -- delete the zombs with some delay since they may not be present as soon as the square is loaded
        queueLen = queueLen + 1
    end

    -- collect all squares loaded recently
    for point,_ in pairs(squaresToCheck) do

        local p = string.find(point, ",")
        local x = tonumber(string.sub(point, 1, p-1))
        local res = string.sub(point, p+1)
        local q = string.find(res, ",")
        local y = tonumber(string.sub(res, 1, q-1))
        local z = tonumber(string.sub(res, q+1))
        local sq = getSquare(x, y, z)

        if sq then -- if square is loaded, put it to the queue
            if removalQueue[removalTime] then  -- shouldn't be necessary but just in case...                    
                table.insert(removalQueue[removalTime], sq)
            end
            squaresToCheck[point] = nil -- don't need to check again
            remainingSquares = remainingSquares - 1
        end
    end 

    if removalQueue[tick] then -- clear the squares we put earlier in the queue from zombies
        for _,sq in pairs(removalQueue[tick]) do
            local zombie = sq:getZombie()
            while zombie do
                zombie:removeFromWorld()
                zombie:removeFromSquare()
                DebugLog.log("rasProfessions_Info: zombie in spawn area removed")
                zombie = sq:getZombie()
            end
        end
        removalQueue[tick] = nil
        queueLen = queueLen - 1
    end

    if queueLen == 0 or tick >= startTickRemove + 100 then       
        Events.OnTick.Remove(removeZombies) -- remove from events
        squaresToCheck = {} -- shouldn't be necessary but just in case...
        remainingSquares = 0 
        startTickRemove = nil 
    end      
end


-- removing zombies from basement requires a special procedure since I don't know how to access the zombies
-- when the basement has not already been discovered by the player; check for basement discovery on every tick but
-- only do this for the first 3 in game hours (not necessary to do this for the whole game)
local discoverTick = nil
local function removeBasementZombies(tick)

    local square = getPlayer():getSquare()

    if square and square:getZ() < 0 and not discoverTick then 
        local xDiff = math.abs(startX - square:getX())
        local yDiff = math.abs(startY - square:getY())
        if xDiff < 22 and yDiff < 22 then
            discoverTick = tick
        end
    end

    if discoverTick and tick >= discoverTick + 2 then -- wait two ticks before removing
        local cell = getCell() -- remove zombies from basements
        if cell then
            local zombies = cell:getZombieList()
            for i=zombies:size(),1,-1 do -- note: list gets smaller when removing zeds, therefore start with i=size
                local zombie = zombies:get(i-1)
                local sq = zombie:getSquare()
                if sq:getZ() < 0 then --only remove basement zeds
                    zombie:removeFromWorld()
                    zombie:removeFromSquare()
                    DebugLog.log("rasProfessions_Info: zombie in basement removed")
                end
            end
        end
        discoverTick = nil
        Events.OnTick.Remove(removeBasementZombies) -- remove from events
    end
end


-- we stop checking for basement zombie removal after 3 hours
local hour = 0
local function stopCheckingForBasements()

    if hour >= 3 then
        Events.OnTick.Remove(removeBasementZombies) -- remove from events
        discoverTick = nil
        Events.EveryHours.Remove(stopCheckingForBasements)    
    end
    hour = hour + 1
end

-- preprocess the zombie removal: collect all square coordinates from which they should be removed and store them in tables
local function preprocessZedRemoval(building)

    local rooms = building:getRooms() -- collect all squares from the building
    for i=1,rooms:size() do
        local room = rooms:get(i-1)
        local minX = room:getX()
        local maxX = room:getX2()
        local minY = room:getY()
        local maxY = room:getY2() 
        local z = room:getZ()
        local m = 30
        if math.abs(startX - minX) < m or math.abs(startX - maxX) < m or math.abs(startY - minY) < m or math.abs(startY - maxY) < m then -- do not fully clear super huge buildings!
            for x=minX,maxX do
                for y=minY,maxY do
                    local point = x .. "," .. y .. "," .. z
                    if not squaresToCheck[point] then
                        squaresToCheck[point] = true
                        remainingSquares = remainingSquares + 1
                    end                    
                end         
            end 
        end
    end       

    local r = 20 -- also take all squares from 40x40 area around the player
    local maxX = startX + r
    local minX = startX - r
    local maxY = startY + r
    local minY = startY - r
    for x=minX,maxX do
        for y=minY,maxY do
            local point = x .. "," .. y .. ",0"
            if not squaresToCheck[point] then
                squaresToCheck[point] = true
                remainingSquares = remainingSquares + 1
            end
        end         
    end

    Events.OnTick.Add(removeZombies) -- start the process
    Events.OnTick.Add(removeBasementZombies)
    Events.EveryHours.Add(stopCheckingForBasements)
end


-- teleport to start location; remove house alarm from starter house; prepare the spawn point (zombie removal etc)
local function manageSpawn(player)

    local profession = player:getDescriptor():getProfession()

    local city = rasSharedData.StartingCity
    if city and rasSharedData["Spawns"][city] and rasSharedData["Spawns"][city][profession] then
        local spawns = rasSharedData["Spawns"][city][profession]
        local n = ZombRand(#spawns) + 1
        local point = spawns[n]
        local x = nil
        local y = nil
        local z = 0
        if point["posX"] and point["posY"] then
            if point["worldX"] then
                x = (point["worldX"]*300) + point["posX"] -- old coordinate format
                if point["worldY"] then
                    y = (point["worldY"]*300) + point["posY"]
                else
                     DebugLog.log("rasProfessions_WARN: Spawnpoint for " .. profession .. " in " .. city .. " not correctly defined!")
                end   
            else
               x = point["posX"]  
               y = point["posY"]
            end
            if point["posZ"] then
                z = point["posZ"]
            end
        else
             DebugLog.log("rasProfessions_WARN: Spawnpoint for " .. profession .. " in " .. city .. " not correctly defined!")
        end
 
        if x and y then
            startX = x
            startY = y
            local building = getWorld():getMetaGrid():getBuildingAt(startX, startY)
            if building then
                building:setAlarmed(false) -- no alarm in starter house
                building:setAllExplored(true) -- test: this might prevent a house from becoming randomized (burnt, barricaded...) but not 100% sure

                player:teleportTo(startX, startY, z) -- teleport player to spawn location
                
                squaresToCheck = {}
                remainingSquares = 0
                preprocessZedRemoval(building) -- this will remove the zombies from starter area

                Events.OnTick.Add(giveHouseKeys) -- add house keys to player inventory
                Events.OnTick.Add(turnLightsOn) -- turn on lights in starter room (to avoid spawning in a black room; can still happen when power is shut off :( )
            end            
        end
    end
end


-- execute everything OnNewGame
local function mainFunction(player)

    Events.OnTick.Add(fixOutOfShape)

    if SandboxVars.RasProfessions.ModdedSpawnPoints then    
        manageSpawn(player)         
    end
end


Events.OnNewGame.Add(mainFunction)





 
